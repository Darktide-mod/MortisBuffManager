-- Preselection keeps the catalog, saved choices and details visible together.
-- Reward modes and bulk room permissions retain the wider browse layout.
local U={}
-- The check used by native Proxima Nova UI (EndView's ready indicator).
local selected_marker="\238\128\129  "
local function shortened(text,width)
    local chars,used={},0
    for c in text:gmatch("[%z\1-\127\194-\244][\128-\191]*")do
        used=used+(#c>1 and 2 or 1)
        if used>(width or 60) then return table.concat(chars).."…" end
        chars[#chars+1]=c
    end
    return text
end
local function text_pages(text,width,lines)
    local tokens,word={},{}
    local function flush_word()
        if #word>0 then tokens[#tokens+1]=table.concat(word);word={}end
    end
    for c in tostring(text):gmatch("[%z\1-\127\194-\244][\128-\191]*")do
        if #c==1 and not c:match("%s")then word[#word+1]=c
        else flush_word();tokens[#tokens+1]=c end
    end
    flush_word()
    local pages,part={},{};local used,line=0,1
    for _,token in ipairs(tokens)do
        local n=token:byte()>127 and 2 or #token
        if token=="\n" or used+n>width and used>0 then
            line=line+1;used=0
            if line>lines then pages[#pages+1]=table.concat(part);part={};line=1 end
        end
        if token=="\n" then
            if #part>0 then part[#part+1]=token end
        elseif token:match("^%s+$")then
            if #part>0 then part[#part+1]=token end
            if used>0 then used=used+n end
        else
            part[#part+1]=token;used=used+n
        end
    end
    pages[#pages+1]=table.concat(part);return pages
end
function U.build(ui,view,mod,Model,library,Examples)
    local function loc(key,...)return mod:localize("diy_"..key,...)end
    local function action(fn)return function()if mod:is_enabled() then fn();view._diy_revision=nil end end end
    local snapshot=Model.snapshot();if not snapshot then ui:text("waiting",105,230,1690,80,loc("policy_pending"),26);return end
    local rules=snapshot.rules
    local limits=rules.diy_limits or library.options
    local function configure(mode,native,diy,limit)
        return Model.rules(mode or rules.mode,limit or rules.limit,native==nil and rules.native_enabled or native,diy==nil and rules.diy_enabled or diy)
    end
    local function integer(maximum,callback,value)
        view._workspace_number={maximum=maximum,callback=callback,text=tostring(value or 0),replace=true,mode=rules.mode,revision=rules.revision}
        view._workspace_searching=nil;view.is_text_input_focused=true
    end
    if view._workspace_subpage=="library" then
        ui:button("back",105,219,220,48,loc("back_catalog"),action(function()view._workspace_subpage=nil end))
        ui:text("library_title",349,221,1446,48,loc("library_settings"),28)
        ui:text("library_help",105,285,1690,68,loc("library_explanation"),21,"muted")
        local file=library.files[library.selected_file]
        ui:button("library_file",105,371,1078,50,file or loc("no_files"),#library.files>0 and action(function()library.selected_file=library.selected_file%#library.files+1 end))
        ui:button("library_scan",1199,371,290,50,loc("scan"),action(library.scan))
        ui:button("library_load",1505,371,290,50,loc(file and library.package_disabled(file) and "package_enable" or "package_disable"),file and action(function()library.toggle_package(file)end))
        local buttons={
            {"paste",function()local raw=Clipboard and Clipboard.get and Clipboard.get();if type(raw)=="string" then library.import_text(raw,"clipboard")end end,true},
            {"example",function()library.export("starter-mortis.json",Examples.mortis)end,true},
            {"export",function()library.export(library.document.id.."-export.json")end,true},
            {"copy_dir",library.copy_directory,true},
        }
        for i,b in ipairs(buttons)do ui:button("library_"..b[1],105+(i-1)*427,443,411,50,loc(b[1]),b[3] and action(b[2]))end
        local package_status,package_error=library.status_message()
        local message=library.last_error or view._workspace_message or library.last_message
        if view._workspace_number then message=loc("number_typing",view._workspace_number.text,view._workspace_number.maximum)end
        if message and library.format_message then message=library.format_message(message)
        elseif message and message:match("^diy_") then message=mod:localize(message)end
        local status_text=message and (package_status.."\n"..message) or package_status
        if view._package_status_text~=status_text then view._package_status_text=status_text;view._package_status_page=1 end
        local pages=text_pages(status_text,140,3)
        ui:text("library_status",105,555,1500,110,pages[view._package_status_page or 1] or pages[1],19,(library.last_error or package_error) and "danger" or "muted")
        if #pages>1 then ui:button("package_status_more",1621,589,174,46,loc("next"),action(function()view._package_status_page=(view._package_status_page or 1)%#pages+1 end))end
        return
    elseif view._workspace_subpage=="rules" then
        ui:button("back",105,219,220,48,loc("back_catalog"),action(function()view._workspace_subpage=nil;view._workspace_number=nil;view.is_text_input_focused=false end))
        ui:text("reward_settings_title",349,221,1446,48,loc("reward_settings"),28)
        ui:text("reward_settings_help",105,285,1690,100,loc("reward_settings_help"),21,"muted")
        local function stepper(key,y,label,value,maximum,enabled,set)
            ui:text(key.."_label",105,y,660,52,label,25,"gold")
            ui:button(key.."_minus",799,y,96,52,"−",enabled and value>0 and action(function()set(value-1)end))
            ui:button(key,911,y,150,52,tostring(value),enabled and action(function()integer(maximum,set,value)end))
            ui:button(key.."_plus",1077,y,96,52,"+",enabled and value<maximum and action(function()set(value+1)end))
        end
        stepper("native_limit",423,mod:localize("mortis_limit_"..rules.mode),rules.limit,99,snapshot.editable and rules.mode~="draft",function(n)configure(nil,nil,nil,n)end)
        stepper("diy_limit",519,loc("points_limit"),limits.max_total,99,snapshot.editable,function(n)Model.diy_rules(n,rules.diy_enabled)end)
        ui:text("tier_label_help",105,617,1690,80,loc("tier_label_help"),21,"muted")
        local edit=view._workspace_number
        ui:text("reward_settings_status",105,725,1690,88,edit and loc("number_typing",edit.text,edit.maximum) or view._workspace_message or loc(snapshot.editable and "points_help" or "settings_locked"),20,"muted")
        return
    elseif view._workspace_subpage=="family" then
        ui:button("back",105,219,220,48,loc("back_catalog"),action(function()view._workspace_subpage=nil end))
        ui:text("family_title",349,221,1446,48,loc("choose_family"),28)
        ui:text("family_help",105,285,1690,68,loc("family_explanation"),21,"muted")
        for i,name in ipairs(mod.mortis_family_names)do
            local data=mod.mortis_choice_ui_data(name,"family")
            local y=370+(i-1)*76
            ui:button("family_"..name,105,y,510,58,data.display_name,snapshot.selection_editable and action(function()
                Model.family(name);view._workspace_subpage=nil;view._workspace_detail=nil
            end),name==snapshot.family)
            ui:text("family_description_"..name,647,y,1148,64,data.description,18,"muted")
        end
        return
    end
    ui:text("workspace_title",105,219,1150,46,loc("workspace_title"),30)
    ui:text("workspace_role",1271,229,524,34,loc(snapshot.editable and "room_editing" or "room_browsing"),20,"muted")
    ui:checkbox("native_pool",105,285,276,52,loc("policy_native"),snapshot.editable and action(function()configure(nil,not rules.native_enabled)end),rules.native_enabled)
    ui:checkbox("diy_pool",397,285,276,52,loc("policy_diy"),snapshot.editable and action(function()configure(nil,nil,not rules.diy_enabled)end),rules.diy_enabled)
    for i,mode in ipairs({"preselect","draft","competition"})do
        ui:button("mode_"..mode,711+(i-1)*222,285,206,52,mod:localize("mortis_mode_"..mode),snapshot.editable and action(function()configure(mode)end),rules.mode==mode)
    end
    ui:button("library_settings",1415,285,380,52,loc("library_settings"),action(function()view._workspace_subpage="library"end))
    local summary
    if snapshot.preselect then summary=loc("preselection_summary",snapshot.native_count,snapshot.limit,snapshot.diy_count,limits.max_total)
    else summary=loc("mode_summary",rules.limit) end
    ui:text("mode_summary",105,352,1280,42,view._workspace_message or summary,21,view._workspace_message and "danger" or "muted")
    ui:button("reward_settings",1415,352,380,42,loc("reward_settings"),action(function()view._workspace_subpage="rules"end))
    local can_batch=snapshot.selection_editable or snapshot.editable
    local bulk=view._workspace_bulk and can_batch
    local split=snapshot.preselect and not bulk
    local list_w=split and 650 or 854
    local filter=view._workspace_filter or "all"
    for i,kind in ipairs({"all","native","diy","available","unavailable"})do
        ui:button("filter_"..kind,105+(i-1)*(split and 133 or 174),405,split and 118 or 158,46,loc("filter_"..kind),action(function()view._workspace_filter=kind;view._workspace_page=1;view._workspace_detail=nil end),filter==kind)
    end
    ui:button("search",105,467,split and 334 or 450,46,loc("search_input")..shortened(view._workspace_search or "",split and 20 or 30)..(view._workspace_searching and " |" or ""),action(function()
        view._workspace_searching=true;view.is_text_input_focused=true
    end))
    ui:button("search_clear",split and 451 or 571,467,split and 126 or 160,46,loc("policy_clear_search"),action(function()view._workspace_search=nil;view._workspace_page=1;view._workspace_searching=nil;view.is_text_input_focused=false end))
    if can_batch then ui:button("batch",split and 589 or 747,467,split and 166 or 212,46,loc(view._workspace_bulk and "batch_done" or "batch"),action(function()
        view._workspace_bulk=not view._workspace_bulk;view._workspace_marked={};view._workspace_batch_result=nil
        view._workspace_batch_target=snapshot.selection_editable and "preselection" or "pool";view._workspace_page=1
    end),view._workspace_bulk)end
    local rows={};local search=string.lower(view._workspace_search or "")
    for _,row in ipairs(snapshot.rows)do
        if (filter=="all" or filter==row.source or filter=="available" and row.available or filter=="unavailable" and not row.available)
            and (search=="" or string.find(string.lower(row.name.." "..row.id.." "..(row.package_id or "").." "..(row.original_id or "")),search,1,true))then rows[#rows+1]=row end
    end
    local per_page=bulk and 6 or 7
    local pages=math.max(1,math.ceil(#rows/per_page));local page=math.max(1,math.min(view._workspace_page or 1,pages));view._workspace_page=page
    local shown
    for _,row in ipairs(split and snapshot.rows or rows)do if row.key==view._workspace_detail then shown=row;break end end
    shown=shown or rows[(page-1)*per_page+1]
    if shown then view._workspace_detail=shown.key end
    local marked=view._workspace_marked or {};view._workspace_marked=marked
    local target=view._workspace_batch_target or "preselection"
    local function inspect(row)
        view._workspace_detail=row.key;view._workspace_detail_page=1;view._workspace_peer_page=1
    end
    local function toggle(row)
        inspect(row);view._workspace_message=nil
        local ok,reason=Model.select(row)
        if not ok then view._workspace_message=reason and mod:localize("mortis_selection_"..reason) or loc("selection_full")end
    end
    for i=1,math.min(per_page,#rows-(page-1)*per_page)do
        local row=rows[(page-1)*per_page+i]
        local selected=split and row.selected or not split and row.acquired
        local label=(selected and selected_marker or "").."["..loc("source_"..row.source).."] "..shortened(row.name,split and 42 or 62)
        local select_row=action(function()inspect(row)end)
        local inspect_row=select_row
        if split and snapshot.selection_editable and (row.selected or row.available)then select_row=action(function()toggle(row)end)end
        if bulk then
            label=(marked[row.key] and "●  " or "○  ")..label;selected=marked[row.key]
            select_row=(target~="pool" or row.source=="diy") and action(function()marked[row.key]=not marked[row.key] or nil end)
        end
        local item=ui:button("skill_"..i,105,533+(i-1)*54,list_w,46,label,select_row,selected)
        item.on_hover=function()if view._workspace_detail~=row.key then inspect_row()end end
        item.muted=not row.available or bulk and target=="pool" and row.source=="native";item.font=19;item.row=true
    end
    if bulk then
        ui:button("batch_select_all",105,863,555,48,loc("select_filtered"),action(function()
            for _,row in ipairs(rows)do if target~="pool" or row.source=="diy" then marked[row.key]=true end end
        end))
        ui:button("batch_clear",676,863,283,48,loc("clear_marked"),action(function()view._workspace_marked={}end))
    end
    if #rows==0 then ui:text("catalog_empty",105,549,list_w,100,loc("policy_empty"),22,"muted")end
    ui:button("previous_page",105,932,70,46,"‹",page>1 and action(function()view._workspace_page=page-1;view._workspace_detail=nil end))
    ui:text("page_count",191,940,list_w-172,38,loc("page_summary",page,pages,#rows),19,"muted")
    ui:button("next_page",105+list_w-70,932,70,46,"›",page<pages and action(function()view._workspace_page=page+1;view._workspace_detail=nil end))
    if split then
        local selected={};for _,row in ipairs(snapshot.rows)do if row.selected then selected[#selected+1]=row end end
        ui:text("selection_title",779,405,280,40,loc("my_selection"),27,"gold")
        ui:button("clear_selection",1075,405,134,42,loc("clear_selection"),snapshot.selection_editable and #selected>0 and action(function()
            local keys={};for _,row in ipairs(selected)do keys[row.key]=true end
            local _,skipped=Model.batch(keys,"preselection",false)
            view._workspace_message=skipped>0 and loc("batch_result",0,skipped) or nil
        end))
        ui:text("selection_counts",779,453,430,28,loc("selection_counts",snapshot.native_count,snapshot.limit,snapshot.diy_count,limits.max_total),19,"muted")
        if rules.native_enabled then
            ui:button("choose_family",779,483,430,34,loc("family_prefix")..mod:localize("mortis_talent_ui_family_"..tostring(snapshot.family)),
                snapshot.selection_editable and action(function()view._workspace_subpage="family"end))
        end
        local spages=math.max(1,math.ceil(#selected/7));local spage=math.max(1,math.min(view._workspace_selected_page or 1,spages));view._workspace_selected_page=spage
        for i=1,math.min(7,#selected-(spage-1)*7)do
            local row=selected[(spage-1)*7+i];local y=533+(i-1)*54
            local item=ui:button("selected_skill_"..i,779,y,376,46,selected_marker..shortened(row.name,30),action(function()inspect(row)end),true)
            item.on_hover=function()if view._workspace_detail~=row.key then inspect(row);view._diy_revision=nil end end
            item.row=true;item.font=18;item.muted=not row.available
            local remove=ui:button("remove_selected_"..i,1163,y,46,46,"×",snapshot.selection_editable and action(function()toggle(row)end))
            remove.on_hover=item.on_hover
        end
        if #selected==0 then ui:text("selection_empty",795,553,398,100,loc("selection_empty"),22,"muted")end
        ui:button("selected_previous",779,932,56,46,"‹",spage>1 and action(function()view._workspace_selected_page=spage-1 end))
        ui:text("selection_page",851,940,286,38,loc("selection_page",spage,spages,#selected),19,"muted")
        ui:button("selected_next",1153,932,56,46,"›",spage<spages and action(function()view._workspace_selected_page=spage+1 end))
        ui:text("selection_hint",105,909,1104,23,loc(snapshot.selection_editable and "preselect_hint" or "selection_locked"),17,"muted")
    end
    if bulk then
        local count=0;for _ in pairs(marked)do count=count+1 end
        ui:text("batch_title",1005,405,790,76,loc("batch_title",count),29,"gold")
        ui:text("batch_help",1005,499,790,144,loc("batch_help"),22,"muted")
        if snapshot.selection_editable then ui:button("batch_target_preselection",1005,659,382,52,loc("batch_preselection"),action(function()
            view._workspace_batch_target="preselection";view._workspace_marked={}
        end),target=="preselection")end
        if snapshot.editable then ui:button("batch_target_pool",1403,659,392,52,loc("batch_diy_pool"),action(function()
            view._workspace_batch_target="pool";view._workspace_marked={}
        end),target=="pool")end
        ui:button("batch_add",1005,759,382,54,loc(target=="pool" and "batch_allow" or "batch_add"),count>0 and action(function()
            local changed,skipped=Model.batch(marked,target,true);view._workspace_batch_result=loc("batch_result",changed,skipped)
        end))
        ui:button("batch_remove",1403,759,392,54,loc(target=="pool" and "batch_disable" or "batch_remove"),count>0 and action(function()
            local changed,skipped=Model.batch(marked,target,false);view._workspace_batch_result=loc("batch_result",changed,skipped)
        end))
        ui:text("batch_result",1005,849,790,130,view._workspace_batch_result or loc(target=="pool" and "native_whole_only" or "batch_preselection_help"),21,"muted")
        return
    end
    local dx,dw=split and 1233 or 1005,split and 562 or 790
    if not shown then ui:text("empty",dx,421,dw,170,loc("policy_empty"),26,"muted");return end
    ui:text("detail_title",dx,405,dw,84,shown.name,27,"gold")
    local state=shown.reason and mod:localize(shown.reason) or loc(shown.available and "in_pool" or "not_in_pool")
    ui:text("detail_state",dx,499,dw,66,state,20,shown.available and "text" or "danger")
    local details=Model.description(shown)
    local pages=text_pages(details,split and 42 or 60,5);local dpage=math.max(1,math.min(view._workspace_detail_page or 1,#pages))
    ui:text("detail_description",dx,575,dw,140,pages[dpage],21,"text")
    if #pages>1 then
        ui:button("description_previous",dx,718,70,32,"‹",dpage>1 and action(function()view._workspace_detail_page=dpage-1 end))
        ui:text("description_page",dx+86,721,dw-172,30,loc("detail_page",dpage,#pages),18,"muted")
        ui:button("description_next",dx+dw-70,718,70,32,"›",dpage<#pages and action(function()view._workspace_detail_page=dpage+1 end))
    end
    local requirements={}
    for _,p in ipairs(shown.missing)do requirements[#requirements+1]=p.name.." — "..loc(p.reason=="missing" and "peer_missing_entry" or "peer_"..p.reason) end
    local weight_info=shown.source=="diy" and loc("weight")..shown.weight.."  ·  "..loc("tier")..shown.tier or loc("native_weight")
    ui:text("detail_weight",dx,756,dw,shown.source=="native" and 108 or 27,weight_info,19,"muted")
    local peers=text_pages(table.concat(requirements,"\n"),split and 38 or 66,3);local ppage=math.max(1,math.min(view._workspace_peer_page or 1,#peers))
    ui:text("detail_requirements",dx,786,dw-96,85,peers[ppage],19,"danger")
    if #peers>1 then ui:button("peer_next",dx+dw-80,797,80,42,tostring(ppage).."/"..#peers,action(function()view._workspace_peer_page=ppage%#peers+1 end))end
    if snapshot.preselect then
        local label=loc(shown.selected and "remove_preselection" or "add_preselection")
        local can_select=snapshot.selection_editable and (shown.selected or shown.available)
        ui:button("select_skill",dx,880,dw,50,label,can_select and action(function()toggle(shown)end),shown.selected)
    else
        ui:text("reward_state",1005,886,382,52,loc(shown.acquired and "already_acquired" or "reward_candidate"),21,"muted")
    end
    if shown.source=="diy" and snapshot.editable then
        ui:button("host_permission",split and dx or 1403,split and 944 or 880,split and dw or 392,50,loc(shown.host_banned and "allow_room" or "disable_room"),(not shown.host_banned or #shown.missing==0) and action(function()Model.toggle_host(shown)end))
    elseif shown.source=="native" then
        ui:text("native_policy",split and dx or 1403,split and 944 or 884,split and dw or 392,50,loc("native_whole_only_short"),20,"muted")
    elseif split then
        ui:text("detail_footer",dx,944,dw,50,loc("settings_locked"),18,"muted")
    end
    if not split then ui:text("detail_footer",1403,944,392,50,view._workspace_message or loc(snapshot.editable and "applies_room" or "settings_locked"),18,"muted")end
end
return U

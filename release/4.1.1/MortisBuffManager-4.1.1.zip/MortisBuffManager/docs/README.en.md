# Mortis Trials Buff Manager

Use native Mortis rewards and editable DIY talents in SoloPlay and Realms. One talent-pool page brings together preselection, progress rewards, competition rewards and room permissions.

## How to use

Enable the mod, close the original inventory and enter /mortisbuffs in chat. The Mortis page is available in all three reward modes. Before starting, choose a mode and switch the native and DIY pools on or off independently. Open Library and limits to import a JSON library or export the starter.

The left list supports source and availability filters, typed search, pasted search and pagination. Select a grey entry to inspect its description and the reason it cannot enter the pool. The right panel shows weight, tier, acquired state and the names of players whose DIY definition is missing or different. Long descriptions and long player lists have their own page controls. Directional navigation and confirm also operate the page controls.

Batch actions mark individual entries or every filtered result across all pages. Choose My preselection to add or remove personal choices, or Room DIY pool to change permissions for everyone. Existing selections stay selected when added again. Entries that cannot be added are skipped with a changed/skipped count.

## Pool switches and host permissions

Native on + DIY on combines both sources. Native on + DIY off uses native rewards. Native off + DIY on uses only DIY. Both off grants neither source through the managed Mortis reward flow.

The native pool can only be enabled or disabled as a whole. The host cannot ban individual native talents; personal native preselection remains free within native eligibility and point limits. Only DIY entries have individual room permissions. The host can exclude one or many DIY talents from both manual preselection and random rewards. Saved choices are retained, unavailable rows are grey, and only players with an affected saved/acquired choice receive a notice.

Every human Realms participant must confirm a matching definition for each DIY entry. A missing or different entry blocks that entry for the whole room, including the host. Extra entries and different library names are allowed when the relevant entry IDs and normalized definitions match. Changing a weight also changes the definition. Player names and reasons appear in the detail panel. Connection and loading states are shown while confirmation is pending. Guests follow the host's switches, permissions and limits. Use the current Mortis release on all players.

## Preselection

Choose a native family and add the desired native and DIY talents before the mission. Native talents use the host's 0–64 point limit; DIY uses a separate 0–32 total limit, default six. Each talent consumes one slot in its own source. Manual DIY selection respects equipment requirements and exclusive groups; random tier quotas do not limit manual selection. Mission entry freezes the imported document and saved preselection. Room configuration and import controls are locked during the mission; the list remains available for inspection.

## Progress and competition

Whenever the native pool is enabled, the opening reward first chooses a native Mortis family and grants its foundation talent. Later rounds grant an available talent from that route and offer a non-route choice. With DIY enabled, those non-route candidates also include eligible DIY talents. With only DIY enabled, the opening is a DIY choice and there are no native family or automatic route rewards. DIY rewards consume these shared reward rounds; there is no additional random DIY opening grant.

Progress mode has ten rounds at the opening and path milestones 8%, 16%, 24%, 32%, 40%, 50%, 60%, 70% and 80%. Native route rewards can bring this to nineteen talents. Only-DIY play can award at most ten, also subject to DIY limits. Maps without a linear path use bounded objective events; Mortis Trials uses waves. Time alone grants no rounds.

Competition gives each player personal kill progress; each 100% earns another round, up to the host's 0–64 round limit including the opening. Defaults: ordinary enemies 0.25%, specialists 5%, elites 2.5%, bosses 40%, weakened bosses 20%, captains/twins 50%. Bot kills do not count. Kill weights support two decimal places. Choose a local bar, bar with percentage, percentage only or hidden indicator. Earned quotas stop further counting while queued rewards finish.

Choose cards with Ctrl+1, Ctrl+2 or Ctrl+3. A choice has sixty seconds, then the host picks randomly; queued choices get a fresh timer after the previous award presentation. Competition automatically grants its last sole candidate. Acquired talents are excluded from future draws. In all modes the catalog remains accessible. Native acquired Buffs also appear in the native Tab list; the unified catalog shows acquired DIY talents.

## DIY templates and probability

Export and load the twelve-entry starter, or edit the JSON files in docs/diy. Supported effects include passive stats, native keywords, conditional events, temporary layers, resource changes and audited native statuses. Native reinforcement requests require Havoc Enemy Director; native pacing pause actions require Havoc Condition Manager. Ordinary Mortis DIY talents do not require either mod.

An entry's weight ranges from 0 to 1000 and defaults to 1; positive fractions are allowed. Zero excludes random offers but still permits manual preselection. Mixed non-route draws give each native candidate weight 1 and each DIY candidate its configured weight. Each slot samples without replacement from the remaining eligible entries: weights 1, 2 and 7 give first-slot probabilities of 10%, 20% and 70%. These are relative weights, not guaranteed whole-card appearance percentages. Native-only play retains native category weighting. DIY random awards obey total, tier and exclusive-group limits, checked again after every grant.

The Fivefold salvo example creates five copies of a ranged attack, including staff attacks, while paying the original ammunition, warp-charge or overheat cost once. Native extra projectiles multiply: a Surge critical shot creates ten projectiles. Shotgun copies reuse the native pellet pattern. Flame and lightning repeat native hit pulses, with native status limits. The ranged_salvo_count modifier accepts integers 1–5, is Mortis-only and combines by maximum rather than multiplying multiple copies of the talent.

## Requirements and installation

Requires Darktide Mod Loader, Darktide Mod Framework and SoloPlay. Realms is optional for player-hosted co-op. English, Simplified Chinese and Traditional Chinese follow the game language. The DMF option Enable custom Mortis Buffs controls the native source; the unified page provides both source switches. Disabling the mod removes its controls and effects while retaining saved data. Other mods replacing the same Mortis reward flow may conflict.

### Vortex installation

- Close the game, import the ZIP using Install From File, enable it and Deploy Mods.
- Place MortisBuffManager after SoloPlay in Load Order; enable Realms for co-op.

### Manual installation

- Close the game and extract the ZIP into Darktide/mods, producing mods/MortisBuffManager.
- Add MortisBuffManager after SoloPlay in mods/mod_load_order.txt.
- Start the game, enable the mod and configure its talent pools.

SoloPlay and Realms: deluxghost. Native Mortis systems and materials: Fatshark.

[DIY guide](diy/GUIDE.en.md)

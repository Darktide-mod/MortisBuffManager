## Temporary input diagnostic build

3.1.2-test.1 is a test build; 3.1.1 remains the stable release. It includes early Ctrl+number capture, prevents the claimed number from also reaching weapon input, and removes the 200 ms selection delay. One held press cannot choose another queued card. It preserves movement, crouch, mouse input and menu priority.

In DMF Mod options → Mortis Trials Buff Manager → Temporary diagnostics, enable Draft input diagnostics on the player experiencing the problem. It is off by default and local to that player. In Realms, enable it on the host as well to collect both sides of validation. The wire protocol is unchanged from 3.1.1.

Reproduce Ctrl+1 / Ctrl+2 / Ctrl+3 with a visible card, including one quick press. Note whether a Buff was chosen and whether a weapon switched. Turn diagnostics off afterwards. The console log under %APPDATA%/Fatshark/Darktide/console_logs contains [InputTrace] entries: card visibility, key and Ctrl state, rejection reason, filtered or passed weapon action, submission and host acknowledgement. No per-frame polling logs are written. Logs cannot establish success before an actual in-game retest.

Import this ZIP with Vortex as a replacement for the installed version; enable only one version. Manual installation follows the steps below. To return to stable, re-enable the 3.1.1 package in Vortex and redeploy. If uploaded to Nexus, place this build in Optional Files and label it as a temporary diagnostic build.

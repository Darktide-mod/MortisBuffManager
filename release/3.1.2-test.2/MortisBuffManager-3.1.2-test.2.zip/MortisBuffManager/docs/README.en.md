# Mortis Trials Buff Manager

Bring native Mortis Buffs into SoloPlay and Realms missions. The host selects one reward mode and one shared point or reward-round limit for the party. Three modes provide preselected builds, map-progress rewards or personal kill rewards.

## Preselection

Open the talent tree before a mission and choose Buffs using category filters, a selected-only view, native icons and a detail panel. Each Buff costs one point. The host sets a shared maximum of N points, from 0–64, using the slider or direct numeric input. Family, class, ability and talent requirements follow native data. Editing is locked once the mission begins.

## Progress mode

At the start, choose one of three shared Mortis routes and immediately receive its foundation Buff. Each later reward round automatically grants one remaining Buff from that route and offers a public / class Buff three-way choice. Route Buffs do not cost an extra reward round. After the route is exhausted, public / class choices continue.

This mode has a fixed 10 reward rounds: the opening route choice plus 9 paired rounds, for up to 19 Buffs. Its numeric control is greyed out in DMF and Realms. Path milestones are 8%, 16%, 24%, 32%, 40%, 50%, 60%, 70% and 80%, so the final reward arrives before the mission ends. Maps without a linear path use main objective starts for bounded stage rewards. Path and objective rewards do not double-count; Mortis Trials uses wave events. Elapsed time does not grant rewards.

## Competition mode

Choose a route at the start. Each player earns personal progress from kills. Every 100% earns one reward round: an automatic remaining Buff from the selected route plus a public / class Buff choice. Route Buffs prioritize foundation requirements. After the route is exhausted, public / class choices continue without a wave schedule.

The host sets N reward rounds, from 0–64, using the slider or direct numeric input. The opening route choice counts as one round; automatic route Buffs do not consume additional rounds. No further reward is granted once the round limit is reached. Overflow kill progress is retained. Already acquired Buffs are excluded: two remaining candidates produce a two-way choice, one remaining candidate is granted automatically, and an empty pool produces no picker.

Default kill progress: regular enemies/hordes 0.25%, specialists 5%, elites 2.5%, ordinary bosses 50%, weakened bosses 50%, captains/twins 50%. The host can adjust all six categories globally with two decimal places. Bot kills do not award a human player's progress.

Choose a local combat indicator in DMF: small bar, bar + percentage, percentage only, or hidden. Hiding the indicator does not stop rewards or hide choice cards.

## Route and Buff choices

Three compact animated cards appear above the centre of the screen. Press Ctrl+1, Ctrl+2 or Ctrl+3 to choose. Choices do not stop movement or capture the mouse; other menus and text entry take priority.

Each choice allows 60 seconds, after which the host chooses randomly. Further reward rounds queue behind the active choice. Each starts with its automatic route grant and a fresh 60-second choice window. Candidates follow native route and class eligibility. If fewer than three remain, only eligible entries are offered; an exhausted pool stops further choices.

Press Tab to view acquired Buffs in the native Mortis category. In progress and competition modes, the talent-tree Mortis button is disabled and displays synchronized reward counts.

## Host settings and Realms

Without Realms, configure the mode, shared limit and kill weights through DMF. With Realms, the host has one global Mortis control row in the preparation list, including in an empty room. Per-player mode and point overrides are not provided. The row can coexist with Talent Point Manager's individual controls.

Click numeric settings to type or paste. Enter or clicking elsewhere confirms; Esc cancels. Realms plus/minus controls repeat after a 400 ms hold.

Guests follow host rules. Deployment indicators show readiness, missing/incompatible installations, resource loading, disabled state and lost connections. An unready or disconnected guest does not block the remaining players. Rejoining the same room and character during a mission retains acquired rewards; another character or mission has separate state. The host owns choices and rewards, and stale or duplicate replies cannot consume another reward. Host migration is not provided.

Reducing the limit restricts active Buffs while retaining saved choices; raising it can restore them. Changing reward mode during a mission starts a new reward run. Configure the intended mode before starting.

## Requirements and compatibility

Requires Darktide Mod Loader, Darktide Mod Framework and SoloPlay. Realms is optional for player-hosted co-op. Talent Point Manager is optional. English, Simplified Chinese and Traditional Chinese follow the game language.

Enable both the DMF switch and custom Mortis Buffs. The feature defaults off, with preselection and a 10-point shared limit. Disabling the mod removes its UI and applied effects while retaining saved choices.

Buffs use original game templates, identifiers and the mission-Buff manager. Native stacking and eligibility rules apply. When managing Mortis Trials, this mod handles rewards without the native modal picker. Other mods replacing the same reward flow can conflict. The mod does not alter permanent progression in official matchmaking.

## Vortex installation

- Close the game and install the requirements. Import the ZIP with Install From File, enable it and select Deploy Mods.
- Place MortisBuffManager after SoloPlay in Load Order; enable Realms for co-op.
- Start the game and enable custom Mortis Buffs in Mod Options, then choose a mode and limit.

## Manual installation

- Close the game. Extract the ZIP into Darktide/mods, producing mods/MortisBuffManager.
- Add MortisBuffManager on its own line after SoloPlay in mods/mod_load_order.txt.
- Start the game and enable the feature in Mod Options.

## Credits

SoloPlay and Realms: deluxghost. Native Mortis systems, Buff definitions and referenced materials: Fatshark.

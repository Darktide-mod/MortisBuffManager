local mod = get_mod("MortisBuffManager")
if mod._workspace_shell_class then return mod._workspace_shell_class end
local BaseView = require("scripts/ui/views/base_view")
local UIWidget = require("scripts/managers/ui/ui_widget")
local Buttons = require("scripts/ui/pass_templates/button_pass_templates")
local Router = mod:io_dofile("MortisBuffManager/scripts/mods/MortisBuffManager/modules/workspace_router")
local Shell = class("MortisBuffManagerWorkspaceShell", "BaseView")
mod._workspace_shell_class = Shell
local tabs = { "equipment", "talents", "mortis" }
local function definition()
  local scene = { screen = { size = { 1920, 1080 }, scale = "fit" },
    header = { parent = "screen", horizontal_alignment = "center", vertical_alignment = "top",
      size = { 1920, 76 }, position = { 0, 0, 900 } } }
  local widgets = { header = UIWidget.create_definition({ { pass_type = "rect",
    style = { color = { 255, 12, 18, 20 } } } }, "header") }
  for i, tab in ipairs(tabs) do
    scene[tab] = { parent = "header", horizontal_alignment = "center", vertical_alignment = "top",
      size = { 260, 52 }, position = { (i - 2) * 276, 12, 2 } }
    local label = mod:localize("workspace_" .. tab)
    widgets[tab] = UIWidget.create_definition(Buttons.terminal_button, tab,
      { text = label, original_text = label }, nil, { text = { font_size = 24 } })
  end
  scene.close = { parent = "header", horizontal_alignment = "right", vertical_alignment = "top",
    size = { 150, 52 }, position = { -24, 12, 2 } }
  widgets.close = UIWidget.create_definition(Buttons.terminal_button, "close",
    { text = mod:localize("workspace_close"), original_text = mod:localize("workspace_close") })
  scene.empty = { parent = "screen", horizontal_alignment = "center", vertical_alignment = "center",
    size = { 1100, 180 }, position = { 0, 0, 0 } }
  widgets.empty = UIWidget.create_definition({ { pass_type = "rect", style = { color = { 240, 12, 18, 20 } } },
    { pass_type = "text", value_id = "text", style = { font_type = "proxima_nova_bold", font_size = 24,
      text_color = { 255, 215, 215, 215 }, text_horizontal_alignment = "center", text_vertical_alignment = "center",
      offset = { 24, 0, 1 }, size = { 1052, 180 } } } }, "empty", { text = mod:localize("workspace_unavailable") })
  return { scenegraph_definition = scene, widget_definitions = widgets }
end

function Shell:init(settings, context)
  self._workspace_session_owned = true
  self._context = context
  self._preview_player = context.player
  self._is_readonly = false
  self._character = context.player:character_id()
  self._connection = Managers.connection and (Managers.connection._connection_host or Managers.connection._connection_client)
  Shell.super.init(self, definition(), settings, context)
  self._pass_draw = true
end

function Shell:on_enter()
  Shell.super.on_enter(self)
  self:_register_event("tpm_workspace_nodes_updated", "event_workspace_nodes_updated")
  for _, tab in ipairs(tabs) do
    self._widgets_by_name[tab].content.hotspot.pressed_callback = function() self:select_page(tab) end
  end
  self._widgets_by_name.close.content.hotspot.pressed_callback = function()
    if self:can_exit() then Managers.ui:close_view(mod._workspace_window_name) end
  end
  if not self:select_page(mod._workspace_requested_tab or self._context.initial_page) then
    for _, tab in ipairs(tabs) do if self:select_page(tab) then break end end
  end
  mod._workspace_requested_tab = nil
end

function Shell:event_workspace_nodes_updated(nodes)
  local talent = get_mod("TalentPointManager")
  if talent and talent:is_enabled() and talent.workspace_nodes_updated then talent.workspace_nodes_updated(self, nodes) end
end

function Shell:select_page(tab)
  local page = Router.page(tab)
  if not page or (page.available and not page.available(self._preview_player)) then return false end
  if self._selected_page == tab and self._child then return true end
  if self._child then
    local current = Managers.ui:view_instance(self._child)
    if current and current.can_exit and not current:can_exit() then return false end
  end
  self._requested_page = tab
  return true
end

function Shell:_close_page()
  if not self._child then return end
  local page = self._page
  if not self._workspace_invalid and page and page.commit then page.commit(self) end
  Managers.ui:close_view(self._child, true)
  self._closing_child = self._child
  self._child, self._page = nil, nil
end

function Shell:update(dt, t, input_service)
  local connection = Managers.connection and (Managers.connection._connection_host or Managers.connection._connection_client)
  local player = Managers.player and Managers.player:local_player_safe(1)
  if not mod:is_enabled() or not self._preview_player or self._preview_player.__deleted
    or player ~= self._preview_player or self._preview_player:character_id() ~= self._character or connection ~= self._connection then
    self._workspace_invalid = player ~= self._preview_player or not player or player.__deleted
      or player:character_id() ~= self._character or connection ~= self._connection
    Managers.ui:close_view(mod._workspace_window_name, true); return false, true
  end
  for _, tab in ipairs(tabs) do
    local page = Router.page(tab)
    local hotspot = self._widgets_by_name[tab].content.hotspot
    hotspot.disabled = not page or (page.available and not page.available(self._preview_player))
    hotspot.is_selected = tab == self._selected_page
  end
  if self._child and not Router.page(self._selected_page) then self:_close_page(); self._selected_page = nil end
  if self._requested_page then
    if self._child then self:_close_page() end
    if not self._closing_child or not Managers.ui:view_instance(self._closing_child) then
      self._closing_child = nil
      local tab = self._requested_page
      local page = Router.page(tab)
      self._requested_page = nil
      if page and (not page.available or page.available(self._preview_player)) then
        self._selected_page, self._page, self._child = tab, page, page.view_name
        if page.prepare then page.prepare(self) end
        Managers.ui:open_view(page.view_name, nil, nil, nil, nil, { parent = self,
          player = self._preview_player, player_mode = true, can_exit = true, is_readonly = false,
          workspace = true, current_profile_equipped_talents = self._current_profile_equipped_talents })
      end
    end
  end
  self._widgets_by_name.empty.visible = not self._child and not self._closing_child
  if input_service:get("back") and self:can_exit() then Managers.ui:close_view(mod._workspace_window_name) end
  Shell.super.update(self, dt, t, input_service)
  return false, true
end

function Shell:can_exit()
  local child = self._child and Managers.ui:view_instance(self._child)
  return not child or not child.can_exit or child:can_exit()
end

function Shell:on_exit()
  self:_close_page()
  Shell.super.on_exit(self)
end

return Shell

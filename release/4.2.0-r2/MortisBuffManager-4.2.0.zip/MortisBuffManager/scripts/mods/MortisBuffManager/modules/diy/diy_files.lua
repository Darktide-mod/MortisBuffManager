-- Windows Unicode filesystem access, on explicit library actions only.
-- No shell, extra DLL, Lua evaluation, or polling during gameplay.
local F={}
local function filename(s)
    if type(s)~="string" or #s>192 or not s:match("^[^%.].*%.json$") or s:find('[%z\1-\31<>:"/\\|?*]') then return false end
    local stem=(s:match("^([^%.]+)") or ""):upper()
    return stem~="CON" and stem~="PRN" and stem~="AUX" and stem~="NUL" and not stem:match("^COM[1-9]$") and not stem:match("^LPT[1-9]$")
end

function F.new(ffi,mod_name)
    if mod_name~="MortisBuffManager" and mod_name~="HavocConditionManager" then return nil,"invalid_mod_directory" end
    if not ffi then return nil,"template_io_unavailable" end
    if not pcall(ffi.typeof,"DT_DIY_FIND_DATA") then
        ffi.cdef[[
        typedef struct { unsigned long attributes; unsigned long times[6]; unsigned long size_high, size_low, reserved[2]; unsigned short name[260], alternate[14]; } DT_DIY_FIND_DATA;
        int __stdcall MultiByteToWideChar(unsigned int,unsigned long,const char*,int,unsigned short*,int);
        int __stdcall WideCharToMultiByte(unsigned int,unsigned long,const unsigned short*,int,char*,int,const char*,int*);
        unsigned long __stdcall GetEnvironmentVariableW(const unsigned short*,unsigned short*,unsigned long);
        int __stdcall CreateDirectoryW(const unsigned short*,void*);
        unsigned long __stdcall GetFileAttributesW(const unsigned short*);
        void* __stdcall FindFirstFileW(const unsigned short*,DT_DIY_FIND_DATA*);
        int __stdcall FindNextFileW(void*,DT_DIY_FIND_DATA*);
        int __stdcall FindClose(void*);
        void* __stdcall CreateFileW(const unsigned short*,unsigned long,unsigned long,void*,unsigned long,unsigned long,void*);
        int __stdcall ReadFile(void*,void*,unsigned long,unsigned long*,void*);
        int __stdcall WriteFile(void*,const void*,unsigned long,unsigned long*,void*);
        int __stdcall FlushFileBuffers(void*);
        int __stdcall CloseHandle(void*);
        int __stdcall MoveFileExW(const unsigned short*,const unsigned short*,unsigned long);
        int __stdcall DeleteFileW(const unsigned short*);
        unsigned long __stdcall GetLastError(void);
        ]]
    end
    local win=ffi.load("kernel32")
    pcall(ffi.cdef,"int __stdcall RemoveDirectoryW(const unsigned short*);")
    local invalid=ffi.cast("void*",-1)
    local function wide(s)
        local n=win.MultiByteToWideChar(65001,8,s,#s,nil,0)
        if n==0 then error("template_name_invalid",0) end
        local out=ffi.new("unsigned short[?]",n+1); win.MultiByteToWideChar(65001,8,s,#s,out,n); return out
    end
    local function utf8(s)
        local n=win.WideCharToMultiByte(65001,0,s,-1,nil,0,nil,nil)
        local out=ffi.new("char[?]",n); win.WideCharToMultiByte(65001,0,s,-1,out,n,nil,nil); return ffi.string(out)
    end
    local env=ffi.new("unsigned short[32768]")
    local n=win.GetEnvironmentVariableW(wide("APPDATA"),env,32768)
    if n==0 or n>=32768 then return nil,"template_io_unavailable" end
    local parent=utf8(env).."/Fatshark/Darktide"
    local root=parent.."/"..mod_name
    local directory=root.."/diy"
    local store={directory=directory}
    local function exists(path) return tonumber(win.GetFileAttributesW(wide(path)))~=4294967295 end
    function store.ensure()
        for _,p in ipairs({root,directory}) do
            if win.CreateDirectoryW(wide(p),nil)==0 and not exists(p) then return nil,"template_io_failed" end
        end
        return true
    end
    function store.list()
        local ok,err=store.ensure(); if not ok then return nil,err end
        local data=ffi.new("DT_DIY_FIND_DATA[1]")
        local handle=win.FindFirstFileW(wide(directory.."/*.json"),data)
        if handle==invalid then if win.GetLastError()==2 then return {} end; return nil,"template_io_failed" end
        local names={}
        repeat
            if math.floor(tonumber(data[0].attributes)/16)%2==0 then names[#names+1]=utf8(data[0].name) end
            if #names>256 then win.FindClose(handle); return nil,"template_library_full" end
        until win.FindNextFileW(handle,data)==0
        local errcode=win.GetLastError(); win.FindClose(handle)
        if errcode~=18 then return nil,"template_io_failed" end
        table.sort(names); return names
    end
    function store.read(name)
        if not filename(name) then return nil,"template_name_invalid" end
        local filename=name
        local handle=win.CreateFileW(wide(directory.."/"..filename),2147483648,1,nil,3,128,nil)
        if handle==invalid then return nil,"template_io_failed" end
        local buffer,nread=ffi.new("char[524289]"),ffi.new("unsigned long[1]")
        local ok=win.ReadFile(handle,buffer,524289,nread,nil); win.CloseHandle(handle)
        if ok==0 then return nil,"template_io_failed" end
        if nread[0]>524288 then return nil,"template_too_large" end
        return ffi.string(buffer,nread[0])
    end
    function store.remove(name)
        if not filename(name) then return nil,"template_name_invalid" end
        local filename=name
        if win.DeleteFileW(wide(directory.."/"..filename))==0 then return nil,"template_io_failed" end
        return true
    end
    function store.write(name,text,overwrite)
        if not filename(name) then return nil,"template_name_invalid" end
        if type(text)~="string" or #text>524288 then return nil,"template_too_large" end
        local filename=name
        local ok,err=store.ensure(); if not ok then return nil,err end
        local dest=directory.."/"..filename
        if not overwrite and exists(dest) then return nil,"template_exists" end
        if not exists(dest) then
            local entries,e=store.list(); if not entries then return nil,e end
            if #entries>=256 then return nil,"template_library_full" end
        end
        local tmp,handle
        for i=1,100 do
            tmp=dest..".writing-"..i
            handle=win.CreateFileW(wide(tmp),1073741824,0,nil,1,128,nil)
            if handle~=invalid then break end
        end
        if handle==invalid then return nil,"template_io_failed" end
        local written=ffi.new("unsigned long[1]")
        local good=win.WriteFile(handle,text,#text,written,nil)~=0 and tonumber(written[0])==#text and win.FlushFileBuffers(handle)~=0
        win.CloseHandle(handle)
        if good then good=win.MoveFileExW(wide(tmp),wide(dest),overwrite and 9 or 8)~=0 end
        if not good then win.DeleteFileW(wide(tmp)); return nil,not overwrite and exists(dest) and "template_exists" or "template_io_failed" end
        return true
    end
    -- Package IO shares Unicode handles with legacy JSON migration, but a
    -- package is always an entire directory committed without overwriting it.
    store.package_directory=directory.."/packages"
    store.export_directory=directory.."/exports"
    local function attributes(path) return tonumber(win.GetFileAttributesW(wide(path))) end
    local function safe_directory(path,create)
        local value=attributes(path)
        if value==4294967295 and create then
            if win.CreateDirectoryW(wide(path),nil)==0 then return nil,"diy_package_io" end
            value=attributes(path)
        end
        if value==4294967295 or math.floor(value/16)%2~=1 or math.floor(value/1024)%2==1 then return nil,"diy_package_path" end
        return true
    end
    local function children(path)
        local valid,why=safe_directory(path,false);if not valid then return nil,why end
        local data=ffi.new("DT_DIY_FIND_DATA[1]");local handle=win.FindFirstFileW(wide(path.."/*"),data)
        if handle==invalid then if win.GetLastError()==2 then return {} end;return nil,"diy_package_io" end
        local out={}
        repeat
            local name=utf8(data[0].name)
            if name~="." and name~=".." then
                out[#out+1]={name=name,attributes=tonumber(data[0].attributes),size=tonumber(data[0].size_low),high=tonumber(data[0].size_high)}
                if #out>256 then win.FindClose(handle);return nil,"diy_package_limit" end
            end
        until win.FindNextFileW(handle,data)==0
        local code=win.GetLastError();win.FindClose(handle)
        if code~=18 then return nil,"diy_package_io" end
        table.sort(out,function(a,b)return a.name<b.name end);return out
    end
    local function ensure_packages()
        local ok,why=store.ensure();if not ok then return nil,why end
        ok,why=safe_directory(root,false);if not ok then return nil,why end
        ok,why=safe_directory(directory,false);if not ok then return nil,why end
        return safe_directory(store.package_directory,true)
    end
    function store.list_packages(valid_id)
        local ok,why=ensure_packages();if not ok then return nil,why end
        local values;values,why=children(store.package_directory);if not values then return nil,why end
        local names,errors={},{}
        for _,value in ipairs(values)do
            if value.name:sub(1,1)~="." then
                if not valid_id(value.name) or math.floor(value.attributes/16)%2~=1 or math.floor(value.attributes/1024)%2==1 then errors[value.name]="diy_package_path"
                else names[#names+1]=value.name end
            end
        end
        if #names>64 then return nil,"diy_package_limit" end
        return names,nil,errors
    end
    function store.read_package(id,valid_id,valid_path)
        if not valid_id(id) then return nil,"diy_package_path" end
        local root_path=store.package_directory.."/"..id
        local files,total,count={},0,0
        local function walk(relative,depth)
            if depth>8 then return nil,"diy_package_path" end
            local path=root_path..(relative~="" and "/"..relative or "")
            local rows,why=children(path);if not rows then return nil,why end
            for _,row in ipairs(rows)do
                local rel=(relative~="" and relative.."/" or "")..row.name
                if not valid_path(rel) or math.floor(row.attributes/1024)%2==1 then return nil,"diy_package_path: "..rel end
                if math.floor(row.attributes/16)%2==1 then
                    local ok;ok,why=walk(rel,depth+1);if not ok then return nil,why end
                else
                    count=count+1;total=total+row.size
                    if count>257 or row.high~=0 or row.size>8388608 or total>33554432 then return nil,"diy_package_limit" end
                    local handle=win.CreateFileW(wide(root_path.."/"..rel),2147483648,1,nil,3,2097280,nil)
                    if handle==invalid then return nil,"diy_package_io: "..rel end
                    local buffer,nread=ffi.new("char[?]",row.size+1),ffi.new("unsigned long[1]")
                    local ok=win.ReadFile(handle,buffer,row.size+1,nread,nil);win.CloseHandle(handle)
                    if ok==0 or tonumber(nread[0])~=row.size then return nil,"diy_package_changed: "..rel end
                    files[rel]=ffi.string(buffer,nread[0])
                end
            end
            return true
        end
        local ok,why=walk("",0);if not ok then return nil,why end
        return files
    end
    local function write_tree(parent,id,files,valid_id,valid_path)
        if not valid_id(id) or type(files)~="table" then return nil,"diy_package_path" end
        local final=parent.."/"..id
        if exists(final) then return nil,"diy_package_exists" end
        local names,total={},0
        for name,bytes in pairs(files)do
            if not valid_path(name) or type(bytes)~="string" or #bytes>8388608 then return nil,"diy_package_path" end
            total=total+#bytes;names[#names+1]=name
        end
        if #names>257 or total>33554432 then return nil,"diy_package_limit" end
        table.sort(names)
        local staging
        for i=1,100 do
            local candidate=parent.."/.building-"..id.."-"..i
            if win.CreateDirectoryW(wide(candidate),nil)~=0 then staging=candidate;break end
        end
        if not staging then return nil,"diy_package_io" end
        local made_files,made_dirs,seen={},{},{}
        local function cleanup()
            for i=#made_files,1,-1 do win.DeleteFileW(wide(made_files[i])) end
            for i=#made_dirs,1,-1 do win.RemoveDirectoryW(wide(made_dirs[i])) end
            win.RemoveDirectoryW(wide(staging))
        end
        for _,name in ipairs(names)do
            local prefix=""
            for part in (name:match("^(.*)/") or ""):gmatch("[^/]+")do
                prefix=prefix=="" and part or prefix.."/"..part
                if not seen[prefix] then
                    local dir=staging.."/"..prefix
                    if win.CreateDirectoryW(wide(dir),nil)==0 then cleanup();return nil,"diy_package_io" end
                    seen[prefix]=true;made_dirs[#made_dirs+1]=dir
                end
            end
            local dest=staging.."/"..name;local bytes=files[name]
            local handle=win.CreateFileW(wide(dest),1073741824,0,nil,1,128,nil)
            if handle==invalid then cleanup();return nil,"diy_package_io" end
            made_files[#made_files+1]=dest
            local written=ffi.new("unsigned long[1]")
            local ok=win.WriteFile(handle,bytes,#bytes,written,nil)~=0 and tonumber(written[0])==#bytes and win.FlushFileBuffers(handle)~=0
            win.CloseHandle(handle)
            if not ok then cleanup();return nil,"diy_package_io" end
        end
        if win.MoveFileExW(wide(staging),wide(final),8)==0 then cleanup();return nil,exists(final) and "diy_package_exists" or "diy_package_io" end
        return final
    end
    function store.write_package(id,files,valid_id,valid_path)
        local ok,why=ensure_packages();if not ok then return nil,why end
        return write_tree(store.package_directory,id,files,valid_id,valid_path)
    end
    function store.export_packages(packages,valid_id,valid_path)
        local ok,why=store.ensure();if not ok then return nil,why end
        ok,why=safe_directory(store.export_directory,true);if not ok then return nil,why end
        local dest
        for i=1,1000 do
            local path=store.export_directory.."/export-"..string.format("%03d",i)
            if win.CreateDirectoryW(wide(path),nil)~=0 then dest=path;break end
        end
        if not dest then return nil,"diy_package_io" end
        local names={};for id in pairs(packages)do names[#names+1]=id end;table.sort(names)
        for _,id in ipairs(names)do
            local path;path,why=write_tree(dest,id,packages[id].files,valid_id,valid_path)
            if not path then return nil,why end
        end
        return dest
    end
    return store
end
return F

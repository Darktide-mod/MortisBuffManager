local mod = get_mod("MortisBuffManager")

local Catalog = mod:io_dofile("MortisBuffManager/scripts/mods/MortisBuffManager/modules/mortis_catalog")

mod._settings = {}

local function checkbox(setting_id, default_value)
	return {
		setting_id = setting_id,
		type = "checkbox",
		default_value = default_value == true,
		title = setting_id,
		tooltip = setting_id .. "_desc",
	}
end

local function talent_points_slider(setting_id)
	return {
		setting_id = setting_id,
		type = "numeric",
		default_value = 30,
		range = { 30, 99 },
		decimals_number = 0,
		title = setting_id,
		tooltip = setting_id .. "_desc",
	}
end

local data = {
	name = mod:localize("mod_name"),
	description = mod:localize("mod_description"),
	is_togglable = true,
	options = {
		widgets = {
			{
				setting_id = "mortis_settings_group",
				type = "group",
				sub_widgets = {
					checkbox("enable_custom_mortis_buffs", false),
					checkbox("enable_local_mortis_buffs", true),
					checkbox("enable_realms_mortis_buffs", true),
					{
						setting_id = "mortis_buff_limit",
						type = "numeric",
						default_value = 32,
						range = { 1, Catalog.max_selection },
						decimals_number = 0,
						title = "mortis_buff_limit",
						tooltip = "mortis_buff_limit_desc",
					},
				},
			},
		},
	},
}

local function read_settings(widgets)
	for _, widget in ipairs(widgets) do
		if widget.type == "group" then
			read_settings(widget.sub_widgets or {})
		elseif widget.setting_id and widget.type ~= "button" then
			mod._settings[widget.setting_id] = mod:get(widget.setting_id)
		end
	end
end

read_settings(data.options.widgets)

return data

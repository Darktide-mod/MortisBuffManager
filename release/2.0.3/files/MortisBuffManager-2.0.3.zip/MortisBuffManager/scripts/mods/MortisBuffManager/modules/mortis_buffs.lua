local mod = get_mod("MortisBuffManager")

local GameModeSurvival = require("scripts/managers/game_mode/game_modes/game_mode_survival")
local HordeMissionBuffsManager = require("scripts/managers/mission_buffs/horde_mission_buffs_manager")
local MissionBuffsAllowedBuffs = require("scripts/managers/mission_buffs/mission_buffs_allowed_buffs")
local HordesBuffsData = require("scripts/settings/buff/hordes_buffs/hordes_buffs_data")
local MissionBuffsParser = require("scripts/ui/constant_elements/elements/mission_buffs/utilities/mission_buffs_parser")
local Catalog = mod:io_dofile("MortisBuffManager/scripts/mods/MortisBuffManager/modules/mortis_catalog")

local PROTOCOL_VERSION = 3
local SELECTION_STORAGE_SETTING = "tamm_mortis_selections_v1"
local FAMILY_STORAGE_SETTING = "tamm_mortis_families_v1"
local UPDATE_INTERVAL = 0.5
local MORTIS_GAMEPLAY_PACKAGE = "content/levels/horde/missions/mission_psykhanium"

local selectable_buffs, known_buffs = Catalog.all_selectable(MissionBuffsAllowedBuffs, HordesBuffsData)
local family_names = Catalog.family_names(MissionBuffsAllowedBuffs)
local buff_ui_data_cache = {}
local state = mod:persistent_table("tamm_mortis_buffs")

state.applied = {}
state.connection = nil
state.elapsed = 0
state.manager = nil
state.network_registered = false
state.pending_selection_submit = false
state.remote_selections = {}
state.rules_broadcast_pending = false
state.rules_request_elapsed = 0
state.rules_revision = state.rules_revision or 1
state.selection_submit_elapsed = 0
state.session_rules = nil
state.waiting_for_gameplay_assets = false

local function normalize_peer_id(peer_id)
	return peer_id and string.lower(tostring(peer_id)) or nil
end

local function setting_enabled(setting_id)
	return mod:is_enabled() and mod._settings[setting_id] == true
end

local function selection_limit()
	local value = tonumber(mod._settings.mortis_buff_limit) or 32

	return math.clamp(math.floor(value + 0.5), 1, Catalog.max_selection)
end

local function is_realms_host()
	local context = mod.session_context()

	return context.is_realms and context.is_realms_host
end

local function is_realms_client()
	local context = mod.session_context()

	return context.is_realms and context.is_realms_client
end

local function editing_selection_limit()
	if is_realms_client() and state.session_rules and state.session_rules.enabled then
		return state.session_rules.limit
	end

	return selection_limit()
end

local function has_local_authority()
	local context = mod.session_context()

	return context.is_solo_play or context.is_realms_host
end

local function manager_preconfigured_rewards_active(manager)
	return setting_enabled("enable_custom_mortis_buffs")
		and manager ~= nil
		and manager._game_mode_name == "survival"
		and manager:_is_server_or_host()
end

local function survival_preconfigured_rewards_active(game_mode)
	return setting_enabled("enable_custom_mortis_buffs")
		and game_mode ~= nil
		and game_mode._is_server == true
end

local function client_preconfigured_rewards_active()
	return is_realms_client()
		and state.session_rules ~= nil
		and state.session_rules.preconfigured == true
end

local function local_scope_enabled()
	return setting_enabled("enable_custom_mortis_buffs")
		and setting_enabled("enable_local_mortis_buffs")
end

local function realms_scope_enabled()
	return setting_enabled("enable_custom_mortis_buffs")
		and setting_enabled("enable_realms_mortis_buffs")
end

local function player_key(player)
	if not player then
		return nil
	end

	return string.format(
		"%s|%s|%s",
		normalize_peer_id(player:peer_id()) or "unknown",
		tostring(player:local_player_id() or 1),
		tostring(player:character_id() or "unknown")
	)
end

local function local_player()
	local player_manager = Managers.player

	return player_manager and player_manager:local_player_safe(1) or nil
end

local function is_own_player(player)
	return player ~= nil and player == local_player()
end

local function selections_storage()
	local stored = mod:get(SELECTION_STORAGE_SETTING)

	return type(stored) == "table" and stored or {}
end

local function families_storage()
	local stored = mod:get(FAMILY_STORAGE_SETTING)

	return type(stored) == "table" and stored or {}
end

local function character_storage_key(player)
	local profile = player and player:profile()
	local character_id = player and player:character_id() or profile and profile.character_id

	return character_id and tostring(character_id) or nil
end

local function stored_selection_for_player(player)
	local key = character_storage_key(player)
	local stored = key and selections_storage()[key]

	return Catalog.sanitize(stored, known_buffs, Catalog.max_selection)
end

local function stored_family_for_player(player)
	local key = character_storage_key(player)
	local stored = key and families_storage()[key]

	if Catalog.is_valid_family(MissionBuffsAllowedBuffs, stored) then
		return stored
	end

	return Catalog.infer_family(MissionBuffsAllowedBuffs, stored_selection_for_player(player))
end

local function save_selection_for_player(player, selection)
	local key = character_storage_key(player)

	if not key then
		return false, "The current character identity is unavailable"
	end

	local all_selections = selections_storage()
	local updated = {}

	for character_id, character_selection in pairs(all_selections) do
		updated[character_id] = character_selection
	end

	updated[key] = Catalog.sanitize(selection, known_buffs, Catalog.max_selection)
	mod:set(SELECTION_STORAGE_SETTING, updated)
	state.pending_selection_submit = is_realms_client()
	state.selection_submit_elapsed = 1

	return true
end

local function save_family_for_player(player, family_name)
	local key = character_storage_key(player)

	if not key or not Catalog.is_valid_family(MissionBuffsAllowedBuffs, family_name) then
		return false, "The current character identity or Mortis family is unavailable"
	end

	local all_families = families_storage()
	local updated = {}

	for character_id, character_family in pairs(all_families) do
		updated[character_id] = character_family
	end

	updated[key] = family_name
	mod:set(FAMILY_STORAGE_SETTING, updated)
	state.pending_selection_submit = is_realms_client()
	state.selection_submit_elapsed = 1

	return true
end

local function player_setup(player)
	if not player then
		return nil
	end

	local profile = player:profile()
	local player_unit = player.player_unit
	local ability_extension = player_unit and ALIVE[player_unit]
		and ScriptUnit.has_extension(player_unit, "ability_system")
	local grenade_ability
	local combat_ability

	if ability_extension then
		local equipped_abilities = ability_extension:equipped_abilities() or {}

		if ability_extension:has_ability_type("grenade_ability") and equipped_abilities.grenade_ability then
			grenade_ability = equipped_abilities.grenade_ability.name
		end
		if ability_extension:has_ability_type("combat_ability") and equipped_abilities.combat_ability then
			combat_ability = equipped_abilities.combat_ability.ability_group
		end
	end

	-- The hub has no spawned unit in some states, so the live ability extension
	-- can be absent while the talent tree is open. Profile talent definitions
	-- carry the same PlayerAbilities records and provide the native-equivalent
	-- fallback needed to build this character's exclusive reward pool.
	local profile_grenade_ability, profile_combat_ability = Catalog.resolve_profile_abilities(profile)

	grenade_ability = grenade_ability or profile_grenade_ability
	combat_ability = combat_ability or profile_combat_ability

	return {
		archetype = player:archetype_name(),
		combat_ability = combat_ability,
		grenade_ability = grenade_ability,
		talents = profile and profile.talents or {},
	}, grenade_ability ~= nil and combat_ability ~= nil
end

local function valid_buffs_for_player(player, family_name)
	local setup, abilities_ready = player_setup(player)

	family_name = family_name or stored_family_for_player(player)
	local buff_names, valid_buffs, sources = Catalog.valid_for_setup(
		MissionBuffsAllowedBuffs,
		known_buffs,
		setup,
		family_name
	)

	return valid_buffs, abilities_ready, buff_names, sources, setup, family_name
end

local function localized_buff_name(buff_name)
	local buff_data = HordesBuffsData[buff_name]
	local title_key = buff_data and buff_data.title

	if type(title_key) == "string" and title_key ~= "" and rawget(_G, "Localize") then
		local success, localized = pcall(Localize, title_key)

		if success
			and type(localized) == "string"
			and localized ~= ""
			and localized ~= title_key
			and localized ~= "<" .. title_key .. ">"
		then
			return localized
		end
	end

	local localization_key = "mortis_option_" .. tostring(buff_name)
	local localized = mod:localize(localization_key)

	return localized ~= localization_key and localized or tostring(buff_name)
end

local function localized_buff_description(buff_name)
	local buff_data = HordesBuffsData[buff_name]

	if not buff_data or type(buff_data.description) ~= "string" or buff_data.description == "" then
		return mod:localize("mortis_talent_ui_no_description")
	end

	-- This is the same formatter used by the native Mortis reward cards. In
	-- addition to localizing the sentence, it expands the Buff's live numeric
	-- stats so the talent-tree picker does not show raw placeholders.
	local success, description = pcall(MissionBuffsParser.get_formated_buff_description, buff_data)
	local localization_key = buff_data.description

	if success
		and type(description) == "string"
		and description ~= ""
		and description ~= localization_key
		and description ~= "<" .. localization_key .. ">"
	then
		return description
	end

	return mod:localize("mortis_talent_ui_no_description")
end

local function buff_ui_data(buff_name)
	local cached = buff_ui_data_cache[buff_name]

	if cached then
		return cached
	end

	local buff_data = HordesBuffsData[buff_name] or {}

	cached = {
		description = localized_buff_description(buff_name),
		display_name = localized_buff_name(buff_name),
		gradient = buff_data.gradient,
		icon = buff_data.icon,
	}
	buff_ui_data_cache[buff_name] = cached

	return cached
end

local function notify_status(status, buff_name, limit)
	local message_key = "mortis_selection_" .. tostring(status)

	if status == "added" or status == "removed" or status == "duplicate" or status == "missing" or status == "incompatible" then
		mod:notify(mod:localize(message_key, localized_buff_name(buff_name)))
	elseif status == "full" then
		mod:notify(mod:localize(message_key, limit))
	else
		mod:notify(mod:localize("mortis_selection_unknown"))
	end
end

local function ui_selection_context()
	local player = local_player()

	if not player then
		mod:notify(mod:localize("mortis_character_unavailable"))

		return nil
	end

	local valid_buffs = valid_buffs_for_player(player)

	return player, valid_buffs
end

mod.add_selected_mortis_buff = function()
	local player, valid_buffs = ui_selection_context()

	if not player then
		return
	end

	local buff_name = mod:get("mortis_buff_to_add")
	local current = stored_selection_for_player(player)
	local limit = editing_selection_limit()
	local updated, status = Catalog.add(current, buff_name, known_buffs, valid_buffs, limit)

	if status == "added" then
		save_selection_for_player(player, updated)
	end

	notify_status(status, buff_name, limit)
end

mod.remove_selected_mortis_buff = function()
	local player = local_player()

	if not player then
		mod:notify(mod:localize("mortis_character_unavailable"))

		return
	end

	local buff_name = mod:get("mortis_buff_to_remove")
	local current = stored_selection_for_player(player)
	local updated, status = Catalog.remove(current, buff_name, known_buffs)

	if status == "removed" then
		save_selection_for_player(player, updated)
	end

	notify_status(status, buff_name, selection_limit())
end

mod.clear_selected_mortis_buffs = function()
	local player = local_player()

	if not player then
		mod:notify(mod:localize("mortis_character_unavailable"))

		return
	end

	save_selection_for_player(player, {})
	mod:notify(mod:localize("mortis_selection_cleared"))
end

mod.show_selected_mortis_buffs = function()
	local player = local_player()

	if not player then
		mod:notify(mod:localize("mortis_character_unavailable"))

		return
	end

	local selection = stored_selection_for_player(player)

	if #selection == 0 then
		mod:notify(mod:localize("mortis_selection_empty"))

		return
	end

	local names = {}
	local display_count = math.min(#selection, 12)

	for i = 1, display_count do
		names[i] = localized_buff_name(selection[i])
	end

	local suffix = #selection > display_count and string.format(" ... (+%d)", #selection - display_count) or ""

	mod:notify(mod:localize("mortis_selection_summary", #selection, table.concat(names, ", ") .. suffix))
end

local function current_connection()
	local connection_manager = Managers.connection

	return connection_manager and (connection_manager._connection_host or connection_manager._connection_client) or nil
end

local function realms_mod()
	local success, realms = pcall(get_mod, "Realms")

	if not success or not realms or not realms:is_enabled() then
		return nil
	end

	return realms
end

local function send_network(rpc_name, recipient, payload)
	local realms = realms_mod()

	if not realms or type(realms.network_send) ~= "function" or not realms.network_is_available() then
		return false
	end

	return realms.network_send(mod, rpc_name, recipient, payload)
end

local function host_rules()
	return {
		enabled = realms_scope_enabled(),
		limit = selection_limit(),
		preconfigured = setting_enabled("enable_custom_mortis_buffs"),
		protocol = PROTOCOL_VERSION,
		revision = state.rules_revision,
	}
end

local function request_host_rules()
	local connection = Managers.connection
	local host_peer_id = connection and connection:host()

	if host_peer_id then
		send_network("tamm_mortis_rules_request_v1", normalize_peer_id(host_peer_id), {
			protocol = PROTOCOL_VERSION,
		})
	end
end

local function current_local_selection_payload()
	local player = local_player()
	local rules = state.session_rules

	if not player or not rules or not rules.enabled then
		return nil
	end

	return {
		archetype = player:archetype_name(),
		character_id = player:character_id(),
		family = stored_family_for_player(player),
		local_player_id = player:local_player_id(),
		protocol = PROTOCOL_VERSION,
		selection = local_scope_enabled() and stored_selection_for_player(player) or {},
	}
end

local function submit_local_selection_to_host()
	local connection = Managers.connection
	local host_peer_id = connection and connection:host()
	local payload = current_local_selection_payload()

	if host_peer_id and payload then
		local sent = send_network("tamm_mortis_selection_submit_v1", normalize_peer_id(host_peer_id), payload)

		if sent then
			state.pending_selection_submit = false
			state.selection_submit_elapsed = 0
		end
	end
end

local function player_for_peer(peer_id, local_player_id)
	local player_manager = Managers.player

	if not player_manager then
		return nil
	end

	return player_manager:player(peer_id, local_player_id)
		or player_manager:player(normalize_peer_id(peer_id), local_player_id)
end

local function send_selection_result(recipient, accepted, message, retry)
	send_network("tamm_mortis_selection_result_v1", recipient, {
		accepted = accepted,
		message = message,
		retry = retry == true,
	})
end

local function on_rules_request(sender_peer_id, payload)
	if not is_realms_host() or type(payload) ~= "table" or payload.protocol ~= PROTOCOL_VERSION then
		return
	end

	send_network("tamm_mortis_rules_v1", sender_peer_id, host_rules())
end

local function on_rules_received(sender_peer_id, rules)
	if not is_realms_client() or type(rules) ~= "table" then
		return
	end

	local connection = Managers.connection
	local expected_host = connection and normalize_peer_id(connection:host())

	if normalize_peer_id(sender_peer_id) ~= expected_host
		or rules.protocol ~= PROTOCOL_VERSION
		or type(rules.enabled) ~= "boolean"
		or type(rules.limit) ~= "number"
		or type(rules.preconfigured) ~= "boolean"
	then
		return
	end

	local incoming_revision = tonumber(rules.revision) or 0

	if state.session_rules and incoming_revision < (state.session_rules.revision or 0) then
		return
	end

	state.session_rules = {
		enabled = rules.enabled,
		limit = math.clamp(math.floor(rules.limit), 1, Catalog.max_selection),
		preconfigured = rules.preconfigured,
		protocol = rules.protocol,
		revision = incoming_revision,
	}
	state.pending_selection_submit = state.session_rules.enabled
	state.selection_submit_elapsed = 1
end

local function on_selection_submitted(sender_peer_id, payload)
	if not is_realms_host() or not realms_scope_enabled() or type(payload) ~= "table" then
		return
	end
	if payload.protocol ~= PROTOCOL_VERSION
		or type(payload.local_player_id) ~= "number"
		or payload.local_player_id % 1 ~= 0
		or payload.local_player_id < 1
		or type(payload.character_id) ~= "string"
		or type(payload.archetype) ~= "string"
		or not Catalog.is_valid_family(MissionBuffsAllowedBuffs, payload.family)
		or type(payload.selection) ~= "table"
	then
		send_selection_result(sender_peer_id, false, "Malformed Mortis Buff selection")

		return
	end

	local peer_id = normalize_peer_id(sender_peer_id)
	local player = player_for_peer(peer_id, payload.local_player_id)
	local profile = player and player:profile()
	local identity_matches = player
		and player:is_human_controlled()
		and player:character_id() == payload.character_id
		and player:archetype_name() == payload.archetype
		and profile ~= nil

	if not identity_matches then
		send_selection_result(sender_peer_id, false, "Player identity does not match the connection", true)

		return
	end

	local valid_buffs, abilities_ready = valid_buffs_for_player(player, payload.family)

	if not abilities_ready then
		send_selection_result(sender_peer_id, false, "Player abilities are not initialized yet", true)

		return
	end

	local selection, validation_error = Catalog.validate(
		payload.selection,
		known_buffs,
		valid_buffs,
		selection_limit()
	)

	if not selection then
		send_selection_result(sender_peer_id, false, validation_error)

		return
	end

	state.remote_selections[peer_id] = state.remote_selections[peer_id] or {}
	state.remote_selections[peer_id][payload.local_player_id] = {
		character_id = payload.character_id,
		family = payload.family,
		selection = selection,
	}

	send_selection_result(sender_peer_id, true, "accepted")
end

local function on_selection_result(sender_peer_id, result)
	if not is_realms_client() or type(result) ~= "table" then
		return
	end

	local connection = Managers.connection
	local expected_host = connection and normalize_peer_id(connection:host())

	if normalize_peer_id(sender_peer_id) ~= expected_host then
		return
	end

	if result.accepted == false then
		state.pending_selection_submit = result.retry == true
		state.selection_submit_elapsed = 0

		if not result.retry then
			mod:notify(mod:localize("mortis_selection_rejected", tostring(result.message)))
		end
	end
end

local function register_realms_network()
	if state.network_registered then
		return
	end

	local realms = realms_mod()

	if not realms or type(realms.network_register) ~= "function" then
		return
	end

	local registrations = {
		tamm_mortis_rules_request_v1 = on_rules_request,
		tamm_mortis_rules_v1 = on_rules_received,
		tamm_mortis_selection_submit_v1 = on_selection_submitted,
		tamm_mortis_selection_result_v1 = on_selection_result,
	}

	for rpc_name, callback_function in pairs(registrations) do
		local registered, registration_error = realms.network_register(mod, rpc_name, callback_function)

		if not registered then
			mod:error("Could not register Realms Mortis RPC %s: %s", rpc_name, tostring(registration_error))

			return
		end
	end

	state.network_registered = true
end

local function reset_network_state(connection)
	state.connection = connection
	state.pending_selection_submit = false
	state.remote_selections = {}
	state.rules_broadcast_pending = is_realms_host()
	state.rules_request_elapsed = 0
	state.selection_submit_elapsed = 0
	state.session_rules = nil
end

local function update_realms_network(dt)
	register_realms_network()

	local connection = current_connection()

	if connection ~= state.connection then
		reset_network_state(connection)
	end

	if is_realms_client() then
		if not state.session_rules then
			state.rules_request_elapsed = state.rules_request_elapsed + dt

			if state.rules_request_elapsed >= 1 then
				state.rules_request_elapsed = 0
				request_host_rules()
			end
		elseif state.pending_selection_submit then
			state.selection_submit_elapsed = state.selection_submit_elapsed + dt

			if state.selection_submit_elapsed >= 1 then
				submit_local_selection_to_host()
			end
		end
	elseif is_realms_host() then
		if state.rules_broadcast_pending then
			local sent = send_network("tamm_mortis_rules_v1", "others", host_rules())

			if sent then
				state.rules_broadcast_pending = false
			end
		end
	else
		state.remote_selections = {}
		state.session_rules = nil
	end
end

local function active_mission_buffs_manager()
	local game_mode_manager = Managers.state and Managers.state.game_mode

	if not game_mode_manager then
		return nil
	end

	local game_mode = game_mode_manager:game_mode()
	local manager = game_mode and game_mode._mission_buffs_manager

	if not manager or not manager._mission_buffs_handler or not manager:_is_server_or_host() then
		return nil
	end

	return manager
end

local function mortis_gameplay_assets_ready()
	local package_manager = Managers.package

	return package_manager ~= nil and package_manager:has_loaded(MORTIS_GAMEPLAY_PACKAGE)
end

local function player_is_ready(player)
	local unit = player and player.player_unit

	return player and player:is_human_controlled()
		and unit ~= nil
		and ALIVE[unit]
		and ScriptUnit.has_extension(unit, "buff_system") ~= nil
end

local function desired_selection_for_player(player)
	if is_own_player(player) then
		if local_scope_enabled() then
			return stored_selection_for_player(player), stored_family_for_player(player)
		end

		return {}, stored_family_for_player(player)
	end

	if is_realms_host() and realms_scope_enabled() then
		local peer_id = normalize_peer_id(player:peer_id())
		local peer_selections = state.remote_selections[peer_id]
		local remote = peer_selections and peer_selections[player:local_player_id()]

		if remote and remote.character_id == player:character_id() then
			return remote.selection, remote.family
		end
	end

	return {}, nil
end

local function remove_owned_buff(manager, player, buff_name)
	if not player_is_ready(player) then
		return false
	end

	local success, removal_error = pcall(
		manager._remove_externally_controlled_buff_from_player,
		manager,
		player,
		buff_name
	)

	if not success then
		mod:error("Could not remove managed Mortis Buff %s: %s", buff_name, tostring(removal_error))
	end

	return success
end

local function add_owned_buff(manager, player, buff_name)
	if not player_is_ready(player) then
		return false
	end

	local handler = manager._mission_buffs_handler

	if handler:does_player_have_buff_saved(player, buff_name) then
		return false
	end

	local success, apply_error = pcall(
		manager._add_externally_controlled_buff_to_player,
		manager,
		player,
		buff_name
	)

	if not success then
		mod:error("Could not apply managed Mortis Buff %s: %s", buff_name, tostring(apply_error))

		return false
	end

	return handler:does_player_have_buff_saved(player, buff_name)
end

local function remove_buff_from_pool(pool, buff_name)
	if type(pool) ~= "table" then
		return
	end

	for i = #pool, 1, -1 do
		if pool[i] == buff_name then
			table.remove(pool, i)
		end
	end
end

local function exclude_selected_buff_from_native_choices(handler, player, buff_name)
	local legendary_pools = handler:get_legendary_buffs_available_for_player(player)

	for _, pool in pairs(legendary_pools or {}) do
		remove_buff_from_pool(pool, buff_name)
	end

	local persistent_data = handler._persistent_data

	if persistent_data and handler:does_player_have_family_selected(player) then
		local priority_pool = persistent_data:get_player_priority_family_buffs_available(player)
		local family_pool = persistent_data:get_player_family_buffs_available(player)

		remove_buff_from_pool(priority_pool, buff_name)
		remove_buff_from_pool(family_pool, buff_name)
	end
end

local function reconcile_player(manager, player)
	local key = player_key(player)

	if not key or not player_is_ready(player) then
		return
	end

	local handler = manager._mission_buffs_handler

	if not handler then
		return
	end

	local is_survival = manager._game_mode_name == "survival"

	-- Survival initializes its legendary/family pools asynchronously from the
	-- backend. Wait for that native initialization to avoid a later duplicate
	-- restore. Ordinary adventure/Havoc missions use MissionBuffsManager too,
	-- but it intentionally has no backend pool; give_buff_to_player creates the
	-- small persistent record on first use in those modes.
	if is_survival and not handler:does_player_have_existing_data(player) then
		return
	end

	local desired, family_name = desired_selection_for_player(player)
	local valid_buffs = valid_buffs_for_player(player, family_name)
	local desired_lookup = {}
	local limit = selection_limit()
	local applied_count = 0
	local removed_count = 0

	for i = 1, math.min(#desired, limit) do
		local buff_name = desired[i]

		if known_buffs[buff_name] and valid_buffs[buff_name] then
			desired_lookup[buff_name] = true
		end
	end

	local owned = state.applied[key] or {}

	for buff_name in pairs(owned) do
		if not desired_lookup[buff_name] then
			if remove_owned_buff(manager, player, buff_name) then
				owned[buff_name] = nil
				removed_count = removed_count + 1
			end
		elseif not handler:does_player_have_buff_saved(player, buff_name) then
			owned[buff_name] = nil
		end
	end

	for buff_name in pairs(desired_lookup) do
		if not owned[buff_name] and add_owned_buff(manager, player, buff_name) then
			owned[buff_name] = true
			applied_count = applied_count + 1
		end

		if is_survival then
			-- A player's legendary pool is initialized before externally selected
			-- Buffs are applied, and the native family pool may be initialized later.
			-- Remove selected entries from both live pools so a native Mortis reward
			-- cannot offer and stack the same Buff a second time.
			exclude_selected_buff_from_native_choices(handler, player, buff_name)
		end
	end

	state.applied[key] = owned

	if applied_count > 0 or removed_count > 0 then
		mod:info(
			"Reconciled preselected Mortis Buffs for %s in %s: applied=%d removed=%d active=%d",
			key,
			tostring(manager._game_mode_name),
			applied_count,
			removed_count,
			table.size(owned)
		)
	end
end

local function reconcile_mortis_buffs()
	local manager = has_local_authority() and active_mission_buffs_manager() or nil

	if manager ~= state.manager then
		state.manager = manager
		state.applied = {}

		if manager then
			mod:info(
				"Preselected Mortis Buff runtime attached to local %s mission",
				tostring(manager._game_mode_name)
			)
		end
	end
	if not manager then
		return
	end

	-- The Mod manifest loads and retains the native Mortis level package on
	-- every peer. Ordinary adventure/Havoc missions do not load those gameplay
	-- resources themselves, so applying a Buff before the asynchronous package
	-- load completes can crash as soon as a periodic/networked particle fires.
	if not mortis_gameplay_assets_ready() then
		if not state.waiting_for_gameplay_assets then
			state.waiting_for_gameplay_assets = true
			mod:info("Waiting for native Mortis gameplay assets before applying preselected Buffs")
		end

		return
	elseif state.waiting_for_gameplay_assets then
		state.waiting_for_gameplay_assets = false
		mod:info("Native Mortis gameplay assets are ready; applying preselected Buffs")
	end

	local player_manager = Managers.player
	local players = player_manager and player_manager:human_players()

	if not players then
		return
	end

	for _, player in pairs(players) do
		reconcile_player(manager, player)
	end
end

local function cleanup_owned_buffs()
	local manager = state.manager
	local player_manager = Managers.player
	local players = manager
		and manager._mission_buffs_handler
		and player_manager
		and player_manager:human_players()

	if manager and players then
		for _, player in pairs(players) do
			local owned = state.applied[player_key(player)] or {}

			for buff_name in pairs(owned) do
				remove_owned_buff(manager, player, buff_name)
			end
		end
	end

	state.applied = {}
	state.manager = nil
end

mod.mortis_buffs_on_all_mods_loaded = function()
	register_realms_network()
end

mod.mortis_buffs_on_setting_changed = function(changed_setting)
	if changed_setting == "enable_custom_mortis_buffs"
		or changed_setting == "enable_local_mortis_buffs"
		or changed_setting == "enable_realms_mortis_buffs"
		or changed_setting == "mortis_buff_limit"
	then
		state.rules_revision = state.rules_revision + 1
		state.rules_broadcast_pending = is_realms_host()
		state.pending_selection_submit = is_realms_client() and state.session_rules ~= nil
		state.selection_submit_elapsed = 1
	end
end

mod.update_mortis_buffs = function(dt)
	update_realms_network(dt)

	state.elapsed = state.elapsed + dt

	if state.elapsed >= UPDATE_INTERVAL then
		state.elapsed = state.elapsed - UPDATE_INTERVAL
		reconcile_mortis_buffs()
	end
end

mod.cleanup_mortis_buffs = function()
	cleanup_owned_buffs()
	state.connection = nil
	state.elapsed = 0
	state.pending_selection_submit = false
	state.remote_selections = {}
	state.rules_broadcast_pending = false
	state.rules_request_elapsed = 0
	state.selection_submit_elapsed = 0
	state.session_rules = nil
	state.waiting_for_gameplay_assets = false
end

-- Preconfigured mode replaces the whole native reward-draft pipeline. Merely
-- hiding the card UI is insufficient: the family choice gates wave one, and
-- queued legendary choices are counted by join-in-progress catch-up. These
-- hooks stop the choices at their server-side sources while preserving normal
-- wave-completion presentation and every non-selection part of survival mode.
mod:hook(HordeMissionBuffsManager, "_request_buff_family_choice", function(func, self, ...)
	if manager_preconfigured_rewards_active(self) then
		-- Do not call buff_family_choice_initiated(): leaving the persistent
		-- requirement false makes every player ready without fabricating a
		-- family or silently granting an unselected family Buff.
		self._mission_buffs_handler:check_if_all_players_chosen_family()

		return
	end

	return func(self, ...)
end)

mod:hook(HordeMissionBuffsManager, "_request_legendary_buff_choice", function(func, self, ...)
	if manager_preconfigured_rewards_active(self) then
		return
	end

	return func(self, ...)
end)

mod:hook(HordeMissionBuffsManager, "_request_family_buff_for_all", function(func, self, ...)
	if manager_preconfigured_rewards_active(self) then
		return
	end

	return func(self, ...)
end)

mod:hook(HordeMissionBuffsManager, "check_catchup_for_new_player", function(func, self, ...)
	if manager_preconfigured_rewards_active(self) then
		return
	end

	return func(self, ...)
end)

mod:hook(HordeMissionBuffsManager, "rpc_client_mission_buffs_buff_choices_received", function(func, self, ...)
	if client_preconfigured_rewards_active() then
		return
	end

	return func(self, ...)
end)

mod:hook(GameModeSurvival, "_handle_giving_buffs_for_wave", function(func, self, ...)
	if survival_preconfigured_rewards_active(self) then
		-- Returning false tells survival progression that no Buff notification
		-- was queued, so it still shows the ordinary wave-complete notification.
		return false
	end

	return func(self, ...)
end)

mod.mortis_selectable_buffs = selectable_buffs
mod.mortis_known_buffs = known_buffs
mod.mortis_family_names = family_names

-- The talent-tree UI intentionally receives a small, read-only snapshot rather
-- than direct access to the network/session state. Selection changes still go
-- through the same persistence and validation path used by the host.
mod.mortis_talent_ui_available = function(player)
	return setting_enabled("enable_custom_mortis_buffs")
		and player ~= nil
		and is_own_player(player)
		and player:is_human_controlled()
end

mod.mortis_talent_ui_snapshot = function(player)
	if not mod.mortis_talent_ui_available(player) then
		return nil
	end

	local selection = stored_selection_for_player(player)
	local selected_lookup = {}

	for i = 1, #selection do
		selected_lookup[selection[i]] = true
	end

	local valid_lookup, abilities_ready, valid_names, sources, setup, family_name = valid_buffs_for_player(player)
	local entries = {}

	local function append_entry(buff_name, valid, selected)
		local ui_data = buff_ui_data(buff_name)
		local source = sources[buff_name] or {}

		entries[#entries + 1] = {
			buff_name = buff_name,
			description = ui_data.description,
			display_name = ui_data.display_name,
			gradient = ui_data.gradient,
			icon = ui_data.icon,
			selected = selected,
			source_family = source.families and source.families[1],
			source_kind = source.kind or "stale",
			source_requirement = source.requirement,
			valid = valid,
		}
	end

	-- Iterate the native pool produced for this exact archetype and equipped
	-- grenade/combat ability. This makes the UI filter explicit rather than
	-- walking the union of every class and hiding entries afterward.
	for i = 1, #valid_names do
		local buff_name = valid_names[i]
		local selected = selected_lookup[buff_name] == true

		append_entry(buff_name, true, selected)
	end

	-- Keep stale selections visible only so a character that changed class or
	-- equipped abilities can remove them. They remain disabled for addition.
	for i = 1, #selection do
		local buff_name = selection[i]

		if not valid_lookup[buff_name] then
			append_entry(buff_name, false, true)
		end
	end

	local source_order = {
		class = 1,
		generic = 2,
		family = 3,
		stale = 4,
	}

	table.sort(entries, function(left, right)
		local left_rank = source_order[left.source_kind] or 5
		local right_rank = source_order[right.source_kind] or 5

		if left_rank ~= right_rank then
			return left_rank < right_rank
		end

		if left.source_family ~= right.source_family then
			return tostring(left.source_family or "") < tostring(right.source_family or "")
		end

		local left_name = string.lower(left.display_name)
		local right_name = string.lower(right.display_name)

		if left_name == right_name then
			return left.buff_name < right.buff_name
		end

		return left_name < right_name
	end)

	local client = is_realms_client()
	local rules_received = not client or state.session_rules ~= nil
	local host_enabled = not client or state.session_rules and state.session_rules.enabled or false

	return {
		abilities_ready = abilities_ready,
		apply_to_self = local_scope_enabled(),
		archetype = setup and setup.archetype,
		entries = entries,
		family = family_name,
		family_names = family_names,
		host_enabled = host_enabled,
		is_realms_client = client,
		limit = editing_selection_limit(),
		rules_received = rules_received,
		selected_count = #selection,
	}
end

mod.set_mortis_family_from_talent_ui = function(player, family_name)
	if not mod.mortis_talent_ui_available(player)
		or not Catalog.is_valid_family(MissionBuffsAllowedBuffs, family_name)
	then
		return false, "unknown"
	end

	local current_family = stored_family_for_player(player)

	if family_name == current_family then
		return false, "unchanged"
	end

	local valid_buffs = valid_buffs_for_player(player, family_name)
	local current = stored_selection_for_player(player)
	local filtered = Catalog.filter_valid(current, known_buffs, valid_buffs, Catalog.max_selection)
	local saved_family, family_error = save_family_for_player(player, family_name)

	if not saved_family then
		return false, "storage", family_error
	end

	local saved_selection, selection_error = save_selection_for_player(player, filtered)

	if not saved_selection then
		return false, "storage", selection_error
	end

	return true, "changed", #current - #filtered
end

mod.toggle_mortis_buff_from_talent_ui = function(player, buff_name)
	if not mod.mortis_talent_ui_available(player) or type(buff_name) ~= "string" then
		return false, "unknown", editing_selection_limit()
	end

	local current = stored_selection_for_player(player)

	for i = 1, #current do
		if current[i] == buff_name then
			local updated, status = Catalog.remove(current, buff_name, known_buffs)

			if status == "removed" then
				local saved, save_error = save_selection_for_player(player, updated)

				if not saved then
					return false, "storage", editing_selection_limit(), save_error
				end
			end

			return status == "removed", status, editing_selection_limit()
		end
	end

	local valid_buffs = valid_buffs_for_player(player)
	local limit = editing_selection_limit()
	local updated, status = Catalog.add(current, buff_name, known_buffs, valid_buffs, limit)

	if status == "added" then
		local saved, save_error = save_selection_for_player(player, updated)

		if not saved then
			return false, "storage", limit, save_error
		end
	end

	return status == "added", status, limit
end

mod.clear_mortis_buffs_from_talent_ui = function(player)
	if not mod.mortis_talent_ui_available(player) then
		return false
	end

	return save_selection_for_player(player, {})
end

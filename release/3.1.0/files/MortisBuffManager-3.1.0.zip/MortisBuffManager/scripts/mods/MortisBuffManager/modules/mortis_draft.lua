-- Host-owned Mortis routes. Time resolves choices; it never earns rewards.
local Draft = { timeout = 60, max_points = 64, progress_max = 10,
    milestones = { 0.08, 0.16, 0.24, 0.32, 0.40, 0.50, 0.60, 0.70, 0.80 } }
local function copy(list)
    local r = {}; for i, v in ipairs(list or {}) do r[i] = v end; return r
end
function Draft.limit(mode, value)
    return math.max(0, math.min(mode == "draft" and 10 or 64, math.floor(value or 0)))
end
function Draft.new(epoch, mode)
    return { epoch = epoch, mode = mode or "draft", earned = 1, milestones = 0, events = {}, players = {}, serial = 0 }
end
function Draft.event(run, key)
    if not key or run.events[key] then return false end
    run.events[key] = true; run.earned = math.min(10, run.earned + 1); return true
end
function Draft.progress(run, fraction)
    if type(fraction) ~= "number" or fraction ~= fraction then return end
    for i, threshold in ipairs(Draft.milestones) do
        if fraction + 0.000001 >= threshold then run.milestones = math.max(run.milestones, i) end
    end
    -- Phase fallback and path catch-up share the same ten slots.
    run.earned = math.max(run.earned, 1 + run.milestones)
end
function Draft.player(run, key)
    local p = run.players[key]
    if not p then p = { selected = {}, version = 0, earned = 1, progress = 0 }; run.players[key] = p end
    return p
end
local function earned(run, p) return run.mode == "competition" and p.earned or run.earned end
function Draft.kill(p, contribution)
    if type(contribution) ~= "number" or contribution ~= contribution or contribution < 0 or contribution > 100 then return end
    p.progress = p.progress + contribution
    local rewards = math.floor((p.progress + 0.000001) / 100)
    p.progress = math.max(0, p.progress - rewards * 100)
    p.earned = math.min(64, p.earned + rewards); p.version = p.version + 1
end
local function available(list, used)
    local r, seen = {}, {}
    for _, name in ipairs(list or {}) do
        if not used[name] and not seen[name] then r[#r + 1] = name; seen[name] = true end
    end
    return r
end
local function owned(p)
    local r = {}; for _, name in ipairs(p.selected) do r[name] = true end; return r
end
local function family_pool(pool, family, used)
    local route = pool.routes[family]
    if not route then return {} end
    local priority = available(route.priority, used)
    return #priority > 0 and priority or available(route.buffs, used)
end
-- Native strategy: category by weight, then a uniform Buff in that category.
-- Work on copies so unselected options remain available for future choices.
local function weighted(groups, weights, count, random)
    local choices, used = {}, {}
    for _ = 1, count do
        local candidates, total = {}, 0
        for _, key in ipairs(groups.order) do
            local list, weight = available(groups[key], used), weights and weights[key] or 1
            if #list > 0 and type(weight) == "number" and weight > 0 and weight < math.huge then
                total = total + weight; candidates[#candidates + 1] = { list = list, weight = weight }
            end
        end
        if total == 0 then break end
        local roll, chosen = random(1000000) / 1000000 * total, candidates[#candidates]
        for _, candidate in ipairs(candidates) do
            roll = roll - candidate.weight
            if roll <= 0 then chosen = candidate; break end
        end
        local name = chosen.list[random(#chosen.list)]
        used[name] = true; choices[#choices + 1] = name
    end
    return choices
end
local function reward_pool(run, p, pool)
    local used = owned(p)
    if not p.family then
        local groups = { order = {} }
        for _, family in ipairs(pool.families) do
            if #family_pool(pool, family, used) > 0 then
                groups.order[#groups.order + 1] = family; groups[family] = { family }
            end
        end
        return "family", groups, pool.family_weights
    end
    local wave = #p.selected -- opening Buff precedes native wave 1.
    if run.mode == "draft" and pool.legendary_waves[wave] then
        local groups = { order = copy(pool.categories) }
        for _, category in ipairs(groups.order) do groups[category] = available(pool.legendary[category], used) end
        return "legendary", groups, pool.wave_weights["wave_" .. wave]
    end
    local candidates = family_pool(pool, p.family, used)
    if run.mode == "competition" and #candidates == 0 then
        -- No wave schedule or three-way legendary choice in competition.
        -- Once the selected route is exhausted, only eligible non-route Buffs remain.
        local merged = {}
        for _, category in ipairs(pool.categories) do
            for _, name in ipairs(pool.legendary[category]) do merged[#merged + 1] = name end
        end
        candidates = available(merged, used)
    end
    return "automatic", candidates
end
local function grant(p, name)
    p.selected[#p.selected + 1] = name; p.version = p.version + 1
end
local function start(run, p, limit, pool, now, random)
    if p.active then return end
    local maximum = math.min(earned(run, p), Draft.limit(run.mode, limit))
    while #p.selected < maximum do
        local kind, candidates, weights = reward_pool(run, p, pool)
        if kind == "automatic" then
            if #candidates == 0 then p.exhausted = true; return end
            grant(p, candidates[random(#candidates)])
        else
            local choices = weighted(candidates, weights, 3, random)
            if kind == "family" and #choices < 3 then
                local used = {}; for _, name in ipairs(choices) do used[name] = true end
                local fallback = available(candidates.order, used)
                while #choices < 3 and #fallback > 0 do choices[#choices + 1] = table.remove(fallback, random(#fallback)) end
            end
            if #choices == 0 then p.exhausted = true; return end
            run.serial = run.serial + 1
            p.active = { id = run.epoch .. ":" .. run.serial, kind = kind, choices = choices, deadline = now + 60 }
            p.version = p.version + 1; p.exhausted = false; return
        end
    end
    p.exhausted = false
end
local function valid_choice(run, p, pool, active)
    local kind, groups, weights = reward_pool(run, p, pool)
    if active.kind ~= kind or kind == "automatic" then return false end
    local valid = {}
    for _, category in ipairs(groups.order) do
        if kind == "family" or not weights or (weights[category] or 1) > 0 then
            for _, name in ipairs(groups[category]) do valid[name] = true end
        end
    end
    for _, name in ipairs(active.choices) do if not valid[name] then return false end end
    return true
end
function Draft.choose(run, p, id, index, limit, pool, now, random)
    local active = p.active
    if not active or id ~= active.id or type(index) ~= "number" or index % 1 ~= 0
        or not active.choices[index] or #p.selected >= Draft.limit(run.mode, limit) then return false end
    if not valid_choice(run, p, pool, active) then
        p.active = nil; start(run, p, limit, pool, now, random); return false
    end
    local name = active.choices[index]
    if active.kind == "family" then
        p.family = name
        local candidates = family_pool(pool, name, owned(p))
        grant(p, candidates[random(#candidates)])
    else grant(p, name) end
    p.last = { id = id, index = index, name = name, kind = active.kind }
    p.active = nil; p.version = p.version + 1
    start(run, p, limit, pool, now, random); return true
end
function Draft.tick(run, p, limit, pool, now, random)
    limit = Draft.limit(run.mode, limit)
    if #p.selected >= math.min(limit, earned(run, p)) then
        if p.active then p.active = nil; p.version = p.version + 1 end
        return
    end
    local active = p.active
    if active and not valid_choice(run, p, pool, active) then p.active = nil; p.version = p.version + 1 end
    active = p.active
    if active and now >= active.deadline then
        -- One interactive timeout per tick. The next card gets a full minute.
        Draft.choose(run, p, active.id, random(#active.choices), limit, pool, now, random)
    else start(run, p, limit, pool, now, random) end
end
function Draft.snapshot(run, p, limit, now)
    limit = Draft.limit(run.mode, limit)
    local spent, total, active = math.min(#p.selected, limit), math.min(earned(run, p), limit), p.active
    return { epoch = run.epoch, mode = run.mode, family = p.family, progress = p.progress, version = p.version,
        limit = limit, earned = total, spent = spent, queued = math.max(0, total - spent - (active and 1 or 0)),
        selected = copy(p.selected), last = p.last and {
            id = p.last.id, index = p.last.index, name = p.last.name, kind = p.last.kind } or nil,
        exhausted = p.exhausted == true,
        active = active and { id = active.id, kind = active.kind, choices = copy(active.choices), remaining = math.max(0, active.deadline - now) } or nil }
end
return Draft

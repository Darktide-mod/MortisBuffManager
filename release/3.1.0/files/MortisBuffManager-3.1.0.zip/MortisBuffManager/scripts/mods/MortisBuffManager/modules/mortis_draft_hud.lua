-- Non-modal HUD: never changes input services, cursor ownership or player state.
local mod = get_mod("MortisBuffManager")
local UIHud = require("scripts/managers/ui/ui_hud")
local UIWidget = require("scripts/managers/ui/ui_widget")
local UIRenderer = require("scripts/managers/ui/ui_renderer")
local UIScenegraph = require("scripts/managers/ui/ui_scenegraph")
local UIWorkspaceSettings = require("scripts/settings/ui/ui_workspace_settings")
local Text = require("scripts/utilities/ui/text")
local HUD = { geometry = { width = 1008, card_width = 328, gap = 12, card_height = 196, top = 72, header = 32,
	progress_width = 220, progress_height = 38, progress_bottom = 150 } }
local instances = setmetatable({}, { __mode = "k" })
local function text_pass(id, x, y, width, height, font, align)
	return { pass_type = "text", value_id = id, value = "", style_id = id,
		style = { font_type = "proxima_nova_bold", font_size = font, text_color = { 255, 232, 229, 210 },
			text_horizontal_alignment = align or "left", text_vertical_alignment = id == "description" and "top" or "center",
			size = { width, height }, offset = { x, y, 5 } } }
end
function HUD.definitions()
	local g = HUD.geometry
	local graph = { screen = UIWorkspaceSettings.screen,
		canvas = { parent = "screen", horizontal_alignment = "center", vertical_alignment = "center", size = { 1920, 1080 }, position = { 0, 0, 300 } },
		panel = { parent = "canvas", horizontal_alignment = "center", vertical_alignment = "top", size = { g.width, g.header + g.card_height }, position = { 0, g.top, 1 } },
		competition_status = { parent = "canvas", horizontal_alignment = "center", vertical_alignment = "bottom",
			size = { g.progress_width, g.progress_height }, position = { 0, -g.progress_bottom, 1 } } }
	local definitions = {}
	definitions.header = UIWidget.create_definition({ text_pass("text", 0, 0, g.width, 28, 21, "center") }, "panel")
	local function bar_visible(content) return content.bar == true end
	definitions.progress = UIWidget.create_definition({
		{ pass_type = "rect", style_id = "background", style = { color = { 160, 12, 20, 18 }, size = { g.progress_width, g.progress_height }, offset = { 0, 0, 0 } } },
		{ pass_type = "rect", style_id = "track", style = { color = { 220, 50, 61, 48 }, size = { g.progress_width - 24, 4 }, offset = { 12, 29, 2 } }, visibility_function = bar_visible },
		{ pass_type = "rect", style_id = "fill", style = { color = { 255, 225, 185, 85 }, size = { 0, 4 }, offset = { 12, 29, 3 } }, visibility_function = bar_visible },
		text_pass("text", 8, 2, g.progress_width - 16, 24, 17, "center"),
	}, "competition_status")
	for i = 1, 3 do
		local id = "card_" .. i
		graph[id] = { parent = "panel", horizontal_alignment = "left", vertical_alignment = "top", size = { g.card_width, g.card_height }, position = { (i - 1) * (g.card_width + g.gap), g.header, 1 } }
		local passes = {
			{ pass_type = "rect", style_id = "background", style = { color = { 220, 12, 20, 18 } } },
			{ pass_type = "texture", value = "content/ui/materials/frames/frame_tile_2px", style_id = "frame", style = { color = { 255, 167, 146, 82 }, offset = { 0, 0, 2 } } },
			{ pass_type = "rect", style_id = "timer", style = { color = { 255, 225, 185, 85 }, size = { g.card_width, 3 }, offset = { 0, g.card_height - 3, 3 } } },
			{ pass_type = "texture", value = "content/ui/materials/frames/talents/talent_icon_container", style_id = "icon",
				style = { size = { 48, 48 }, offset = { 14, 10, 4 }, color = { 255, 255, 255, 255 },
					material_values = { intensity = 0, saturation = 1, texture_map = "",
						frame = "content/ui/textures/frames/horde/hex_frame_horde", icon_mask = "content/ui/textures/frames/horde/hex_frame_horde_mask" } },
				visibility_function = function(content) return content.has_icon == true end },
			text_pass("title", 74, 10, 240, 48, 20),
			text_pass("description", 16, 66, 296, 82, 18),
			text_pass("key", 16, 158, 296, 28, 18, "center"),
		}
		definitions[id] = UIWidget.create_definition(passes, id)
	end
	return graph, definitions
end
local function cleanup(hud)
	local ui = instances[hud]
	if ui and hud._ui_renderer then
		for _, widget in pairs(ui.widgets) do UIWidget.destroy(hud._ui_renderer, widget) end
	end
	instances[hud] = nil
end
function HUD.cleanup() for hud in pairs(instances) do cleanup(hud) end end
local function instance(hud)
	local ui = instances[hud]
	if ui then return ui end
	local graph, definitions = HUD.definitions()
	ui = { graph = UIScenegraph.init_scenegraph(graph), widgets = {}, age = 0 }
	for name, definition in pairs(definitions) do ui.widgets[name] = UIWidget.init("mbm_draft_" .. name, definition) end
	instances[hud] = ui
	return ui
end
local function allowed(hud)
	local player = Managers.player and Managers.player:local_player_safe(1)
	return mod:is_enabled() and player and hud._player == player and Managers.world:is_world_enabled(hud._world_name)
		and Managers.package and Managers.package:has_loaded("packages/ui/constant_elements/mission_buffs/mission_buffs")
end
local function keyboard_choice()
	if not Keyboard or not Keyboard.button_index then return end
	local left, right = Keyboard.button_index("left ctrl"), Keyboard.button_index("right ctrl")
	if not (left and Keyboard.button(left) > 0 or right and Keyboard.button(right) > 0) then return end
	for i = 1, 3 do local key = Keyboard.button_index(tostring(i)); if key and Keyboard.pressed(key) then return i end end
end
mod:hook_safe(UIHud, "update", function(hud, dt, t, input)
	if not allowed(hud) then return end
	local snapshot, lag, pending = mod.mortis_draft_snapshot()
	if not snapshot then return end
	local ui = instance(hud)
	ui.age = ui.age + dt
	local active = snapshot.active
	if ui.id and (not active or active.id ~= ui.id) then
		if not ui.resolving then
			ui.resolving = 0
			ui.selected = snapshot.last and snapshot.last.id == ui.id and snapshot.last.index or nil
		end
		ui.resolving = ui.resolving + dt
		if ui.resolving >= 0.65 then ui.id, ui.resolving, ui.selected = nil, nil, nil end
	end
	if active and not ui.id then
		ui.id, ui.choices, ui.age, ui.kind = active.id, active.choices, 0, active.kind
		for i = 1, 3 do
			local widget, name = ui.widgets["card_" .. i], active.choices[i]
			local data = name and mod.mortis_choice_ui_data(name, active.kind)
			widget.content.title = data and data.display_name or mod:localize("mortis_pool_empty")
			widget.content.description = data and data.description or ""
			-- Use native font measurement only when the cards change.
			for _, text_id in ipairs({ "title", "description" }) do
				local style = widget.style[text_id]
				style.font_size = text_id == "title" and 20 or 18
				if UIRenderer.styled_text_size then
					local _, height = UIRenderer.styled_text_size(hud._ui_renderer, widget.content[text_id], style, style.size)
					while height > style.size[2] and style.font_size > 14 do
						style.font_size = style.font_size - 1
						_, height = UIRenderer.styled_text_size(hud._ui_renderer, widget.content[text_id], style, style.size)
					end
					if height > style.size[2] and Text.crop_to_size then
						widget.content[text_id] = Text.crop_to_size(hud._ui_renderer, widget.content[text_id], style, { style.size[1], style.size[2] })
					end
				end
			end
			widget.content.has_icon = data and data.icon ~= nil or false
			widget.style.icon.material_values.icon = data and data.icon
			widget.style.icon.material_values.gradient_map = data and data.gradient
		end
	end
	if active and active.id == ui.id and not pending and not ui.resolving and ui.age >= 0.2
		and input and not input:is_null_service() and not Managers.ui:using_input() then
		local index = keyboard_choice()
		if index and active.choices[index] then mod.choose_mortis_draft(index) end
	end
	ui.remaining = active and math.max(0, active.remaining - (lag or 0)) or 0
	ui.widgets.header.content.text = mod:localize(pending and "mortis_draft_sending" or ui.kind == "family" and "mortis_route_header" or "mortis_draft_header", math.ceil(ui.remaining), snapshot.queued, snapshot.spent, snapshot.limit)
	local progress = ui.widgets.progress
	local display = mod._settings.mortis_competition_hud_style or "bar_percent"
	progress.content.show = display ~= "hidden"
	progress.content.bar = display ~= "percent" and display ~= "hidden"
	progress.content.text = snapshot.mode == "competition" and display ~= "bar" and display ~= "hidden"
		and mod:localize("mortis_competition_percentage", snapshot.progress) or ""
	progress.style.fill.size[1] = (HUD.geometry.progress_width - 24) * math.clamp(snapshot.progress / 100, 0, 1)
	progress.style.text.offset[2] = progress.content.bar and 2 or 7
	local background = progress.style.background
	background.size[1] = display == "percent" and 96 or HUD.geometry.progress_width
	background.size[2] = display == "bar" and 14 or display == "percent" and 30 or HUD.geometry.progress_height
	background.offset[1] = (HUD.geometry.progress_width - background.size[1]) / 2
	background.offset[2] = (HUD.geometry.progress_height - background.size[2]) / 2
	progress.style.track.offset[2] = display == "bar" and 17 or 29
	progress.style.fill.offset[2] = progress.style.track.offset[2]
end)
mod:hook_safe(UIHud, "draw", function(hud, dt, t, input)
	if not allowed(hud) then return end
	local snapshot = mod.mortis_draft_snapshot()
	local ui = instances[hud]
	if not snapshot or not ui then return end
	local ui_manager = Managers.ui
	if ui_manager:using_input() then return end
	local alpha = math.min(1, ui.age / 0.35)
	if ui.resolving then alpha = math.min(1, (0.65 - ui.resolving) / 0.2) end
	local settings = { scale = RESOLUTION_LOOKUP.scale, inverse_scale = RESOLUTION_LOOKUP.inverse_scale, alpha_multiplier = alpha, force_retained_mode = false }
	UIScenegraph.update_scenegraph(ui.graph)
	UIRenderer.begin_pass(hud._ui_renderer, ui.graph, input, dt, settings)
	if ui.id then
		UIWidget.draw(ui.widgets.header, hud._ui_renderer)
		for i = 1, 3 do
			local widget = ui.widgets["card_" .. i]
			widget.offset[2] = -18 * (1 - math.min(1, ui.age / 0.35))
			widget.style.frame.color[2] = ui.selected == i and 255 or 167
			widget.style.frame.color[3] = ui.selected == i and 220 or 146
			widget.style.background.color[2] = ui.selected == i and 74 or 12
			widget.style.timer.size[1] = HUD.geometry.card_width * math.min(1, ui.remaining / 60)
			widget.content.key = ui.selected == i and mod:localize("mortis_draft_chosen") or "Ctrl + " .. i
			if ui.choices[i] then UIWidget.draw(widget, hud._ui_renderer) end
		end
	end
	if snapshot.mode == "competition" and ui.widgets.progress.content.show then
		-- Always visible in combat, including while a reward card is active.
		settings.alpha_multiplier = 1
		UIWidget.draw(ui.widgets.progress, hud._ui_renderer)
	end
	UIRenderer.end_pass(hud._ui_renderer)
end)
mod:hook(UIHud, "destroy", function(func, hud, ...) cleanup(hud); return func(hud, ...) end)
return HUD

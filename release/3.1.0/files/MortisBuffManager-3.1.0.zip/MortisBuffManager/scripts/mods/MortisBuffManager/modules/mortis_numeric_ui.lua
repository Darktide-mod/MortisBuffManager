-- Keep DMF's native numeric editor and expose its input box while idle.
local mod = get_mod("MortisBuffManager")
local Numeric = {}
local fields = { mortis_buff_limit = true, mortis_kill_horde = true, mortis_kill_special = true,
    mortis_kill_elite = true, mortis_kill_boss = true, mortis_kill_weakened_boss = true, mortis_kill_captain = true }
function Numeric.decorate(widget, config)
    if not widget or not fields[config.setting_id] or not widget.content.input_hotspot then return end
    widget._mbm_numeric = true
    for _, pass in ipairs(widget.passes) do
        if pass.style_id == "background" or pass.style_id == "baseline" then
            local original = pass.visibility_function
            pass.visibility_function = function(content, style)
                if mod:is_enabled() then return true end
                return not original or original(content, style)
            end
        end
    end
end
function Numeric.cancel(view, input)
    local widget = view._selected_settings_widget
    if not mod:is_enabled() or not widget or not widget._mbm_numeric or not input or not input:get("back") then return end
    local content = widget.content
    if not content.is_writing then return end
    local entry = content.entry
    -- Native finish_editing still clears focus, selection and validation.
    -- Restoring the current value first makes Esc a cancel rather than a commit.
    content.input_text = string.format(content.numeric_number_format, entry.get_function(entry) or entry.default_value)
end
mod:hook("DMFOptionsView", "_create_settings_widget_from_config", function(func, view, config, ...)
    if config.setting_id == "mortis_buff_limit" then config.max_value = mod._settings.mortis_mode == "draft" and 10 or 64 end
    local widget, alignment = func(view, config, ...)
    Numeric.decorate(widget, config)
    if widget and widget._mbm_numeric then
        view._mbm_numeric_widgets = view._mbm_numeric_widgets or setmetatable({}, { __mode = "k" })
        view._mbm_numeric_widgets[widget] = true
    end
    return widget, alignment
end)
mod:hook("DMFOptionsView", "update", function(func, view, dt, t, input, ...)
    for widget in pairs(view._mbm_numeric_widgets or {}) do
        local entry = widget.content.entry
        if entry and entry.setting_id == "mortis_buff_limit" then entry.max_value = mod._settings.mortis_mode == "draft" and 10 or 64 end
    end
    Numeric.cancel(view, input)
    return func(view, dt, t, input, ...)
end)
return Numeric

local mod = get_mod("MortisBuffManager")
local Router = {}
local owners = { "realms_loadout", "TalentPointManager", "MortisBuffManager" }

function Router.page(tab)
  local names = { equipment = "realms_loadout", cosmetics = "realms_loadout", forge = "realms_loadout",
    talents = "TalentPointManager", mortis = "MortisBuffManager" }
  local provider = names[tab] and get_mod(names[tab])
  return provider and provider:is_enabled() and provider.workspace_page or nil
end

function Router.open(tab)
  if not mod:is_enabled() or not Managers.ui then return false end
  local player = Managers.player and Managers.player:local_player_safe(1)
  if not player then return false end
  -- Reuse whichever independent provider opened the window, in either load order.
  for _, name in ipairs(owners) do
    local provider = get_mod(name)
    local window = provider and provider._workspace_window_name
    local view = window and Managers.ui:view_instance(window)
    if view then return view:select_page(tab) end
    if window and Managers.ui:view_active(window) then
      provider._workspace_requested_tab = tab
      return true
    end
  end
  if Managers.ui:view_instance("inventory_background_view") then
    mod:notify(mod:localize("workspace_close_native")); return false
  end
  local page = Router.page(tab)
  if not page then return false end
  local realms = get_mod("Realms")
  local preparation = realms and realms._preparation
  if preparation and preparation.is_finalizing and preparation.is_finalizing() then return false end
  if preparation and preparation.is_waiting and preparation.is_waiting()
    and preparation.local_ready and preparation.local_ready() then preparation.perform_action() end
  local provider = mod
  for _, name in ipairs(owners) do
    local candidate = get_mod(name)
    if candidate and candidate:is_enabled() and candidate._workspace_window_name then provider = candidate; break end
  end
  Managers.ui:open_view(provider._workspace_window_name, nil, nil, nil, nil,
    { player = player, initial_page = tab, is_readonly = false })
  return true
end

function Router.install()
  if mod._workspace_window_name then return end
  mod._workspace_window_name = "mortisbuffmanager_workspace_view"
  mod:add_require_path("MortisBuffManager/scripts/mods/MortisBuffManager/modules/workspace_shell")
  mod:register_view({ view_name = mod._workspace_window_name,
    view_settings = { class = "MortisBuffManagerWorkspaceShell", path = "MortisBuffManager/scripts/mods/MortisBuffManager/modules/workspace_shell",
      package = "packages/ui/views/talent_builder_view/talent_builder_view", state_bound = true,
      init_view_function = function() return true end }, view_transitions = {} })
  mod:command("mbm", mod:localize("workspace_command"), function() return Router.open("mortis") end)
end

function Router.cleanup()
  mod._workspace_requested_tab = nil
  if Managers.ui and mod._workspace_window_name and Managers.ui:view_active(mod._workspace_window_name) then
    Managers.ui:close_view(mod._workspace_window_name, true)
  end
end

return Router

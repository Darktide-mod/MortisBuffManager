-- Pure host-owned draft state. Time only resolves a choice; it never earns one.
local Draft = { timeout = 60, max_points = 64 }
local function copy(list)
	local result = {}; for i, value in ipairs(list or {}) do result[i] = value end; return result
end
function Draft.new(epoch, mode)
	return { epoch = epoch, mode = mode or "draft", earned = 1, milestones = 0, events = {}, players = {}, serial = 0 }
end
function Draft.event(run, key)
	if not key or run.events[key] then return false end
	run.events[key] = true
	run.earned = math.min(Draft.max_points, run.earned + 1)
	return true
end
function Draft.progress(run, fraction)
	if type(fraction) ~= "number" or fraction ~= fraction then return end
	local step = math.max(0, math.min(9, math.floor(fraction * 10 + 0.00001)))
	while run.milestones < step do
		run.milestones = run.milestones + 1
		Draft.event(run, "path:" .. run.milestones)
	end
end
function Draft.player(run, key)
	local player = run.players[key]
	if not player then
		player = { selected = {}, version = 0, earned = 1, progress = 0 }; run.players[key] = player
	end
	return player
end
local function cap(value) return math.max(0, math.min(Draft.max_points, math.floor(value or 0))) end
local function earned(run, player) return run.mode == "competition" and player.earned or run.earned end
function Draft.kill(player, contribution)
	if type(contribution) ~= "number" or contribution ~= contribution or contribution < 0 or contribution > 100 then return end
	player.progress = player.progress + contribution
	local rewards = math.floor((player.progress + 0.000001) / 100)
	player.progress = player.progress - rewards * 100
	player.earned = math.min(Draft.max_points, player.earned + rewards)
	player.version = player.version + 1
end
local function start(run, player, limit, pool, now, random)
	if player.active or #player.selected >= math.min(earned(run, player), cap(limit)) then return end
	local used, available = {}, {}
	for _, name in ipairs(player.selected) do used[name] = true end
	for _, name in ipairs(pool) do
		if not used[name] then available[#available + 1] = name; used[name] = true end
	end
	if #available == 0 then player.exhausted = true; return end
	player.exhausted = false
	local choices = {}
	for i = 1, math.min(3, #available) do choices[i] = table.remove(available, random(#available)) end
	run.serial = run.serial + 1
	player.active = { id = run.epoch .. ":" .. run.serial, choices = choices, deadline = now + Draft.timeout }
	player.version = player.version + 1
end
function Draft.choose(run, player, id, index, limit, pool, now, random)
	local active = player.active
	if not active or id ~= active.id or type(index) ~= "number" or index % 1 ~= 0
		or not active.choices[index] or #player.selected >= cap(limit) then return false end
	local name = active.choices[index]
	local valid = false; for _, candidate in ipairs(pool) do if candidate == name then valid = true; break end end
	if not valid then player.active = nil; start(run, player, limit, pool, now, random); return false end
	player.selected[#player.selected + 1] = name
	player.last = { id = id, index = index, name = name }
	player.active = nil; player.version = player.version + 1
	start(run, player, limit, pool, now, random)
	return true
end
function Draft.tick(run, player, limit, pool, now, random)
	limit = cap(limit)
	if #player.selected >= math.min(limit, earned(run, player)) then
		if player.active then player.active = nil; player.version = player.version + 1 end
		return
	end
	local active = player.active
	if active then
		local valid = {}; for _, name in ipairs(pool) do valid[name] = true end
		for _, name in ipairs(active.choices) do
			if not valid[name] then player.active = nil; player.version = player.version + 1; break end
		end
	end
	active = player.active
	if active and now >= active.deadline then
		-- Exactly one timeout per tick. A delayed update cannot consume the queue.
		Draft.choose(run, player, active.id, random(#active.choices), limit, pool, now, random)
	else start(run, player, limit, pool, now, random) end
end
function Draft.snapshot(run, player, limit, now)
	limit = cap(limit)
	local spent = math.min(#player.selected, limit)
	local earned = math.min(earned(run, player), limit)
	local active = player.active
	return { epoch = run.epoch, mode = run.mode, progress = player.progress, version = player.version, limit = limit, earned = earned, spent = spent,
		queued = math.max(0, earned - spent - (active and 1 or 0)), selected = copy(player.selected),
		last = player.last and { id = player.last.id, index = player.last.index, name = player.last.name } or nil,
		exhausted = player.exhausted == true,
		active = active and { id = active.id, choices = copy(active.choices), remaining = math.max(0, active.deadline - now) } or nil }
end
return Draft

# Mortis Trials Buff Manager

Bring native Mortis Buffs into SoloPlay and Realms missions. The host selects one reward mode and one shared point or reward-round limit for the party. Three modes provide preselected builds, map-progress rewards or personal kill rewards.

## Integrated pages and DIY talents

Preselection uses the full character workspace content area, with the same native tab bar and controls as equipment and talents. A separate DIY talents tab loads editable JSON libraries alongside all three reward modes. DIY talents have their own selection limit and do not consume native points or reward rounds.

Export the starter library, edit its 11 examples, then load the file or paste a complete JSON document. Choose entries manually or use seeded weighted selection with tier quotas and exclusive groups. Configure passive stats, native keywords, conditions, events, temporary stacks, resource changes and supported native statuses. Invalid imports keep the previous valid library; mission entry freezes the current configuration.

The installation includes three-language guides, a complete native identifier catalog and editable templates in docs/diy. Enable the Mortis master switch and DIY before starting. In Realms, participating clients need the same library as the host; each character's accepted choice is fixed for the mission. Advanced reinforcement actions require Havoc Enemy Director; native pacing pauses require Havoc Condition Manager.

[DIY guide](diy/GUIDE.en.md) · [Image assessment](diy/IMAGE-ASSESSMENT.en.md)

## How to use

Enable custom Mortis Buffs in Mod Options → Mortis Buff Manager and choose a reward mode. In preselection mode, type /mortisbuffs in chat before the mission to open this mod’s Buff selector; no key binding is required. You can also assign an optional shortcut in this mod’s DMF settings.

The selector opens in the inventory workspace and is not opened from the I-key talent tree. Close the original inventory before opening it. Progress and competition modes disable preselection; choose offered rewards during the mission with Ctrl+1, Ctrl+2 or Ctrl+3.

This mod adds its own Mortis Buffs page to the inventory window. Equipment, Cosmetics and Talents retain their native behavior unless an enabled extension replaces them. Disabling the mod removes its page and controls.

## Preselection

Open /mortisbuffs before a mission and choose Buffs using category filters, a selected-only view, native icons and a detail panel. Each Buff costs one point. The host sets a shared maximum of N points, from 0–64, using the slider or direct numeric input. Family, class, ability and talent requirements follow native data. Editing is locked once the mission begins.

## Progress mode

At the start, choose one of three shared Mortis routes and immediately receive its foundation Buff. Each later reward round automatically grants one remaining Buff from that route and offers a public / class Buff three-way choice. Route Buffs do not cost an extra reward round. After the route is exhausted, public / class choices continue.

This mode has a fixed 10 reward rounds: the opening route choice plus 9 paired rounds, for up to 19 Buffs. Its numeric control is greyed out in DMF and Realms. Path milestones are 8%, 16%, 24%, 32%, 40%, 50%, 60%, 70% and 80%, so the final reward arrives before the mission ends. Maps without a linear path use main objective starts for bounded stage rewards. Path and objective rewards do not double-count; Mortis Trials uses wave events. Elapsed time does not grant rewards.

## Competition mode

Choose a route at the start. Each player earns personal progress from kills. Every 100% earns one reward round: an automatic remaining Buff from the selected route plus a public / class Buff choice. Route Buffs prioritize foundation requirements. After the route is exhausted, public / class choices continue without a wave schedule.

The host sets N reward rounds, from 0–64, using the slider or direct numeric input. The opening route choice counts as one round; automatic route Buffs do not consume additional rounds. No further reward is granted once the round limit is reached. Overflow progress is retained while rewards remain. Once the quota is earned, kill counting stops and the progress indicator disappears; queued choices still finish normally. Raising the quota resumes eligible counting. Already acquired Buffs are excluded: two remaining candidates produce a two-way choice, one remaining candidate is granted automatically, and an empty pool produces no picker.

Default kill progress: regular enemies/hordes 0.25%, specialists 5%, elites 2.5%, ordinary bosses 40%, weakened bosses 20%, captains/twins 50%. The host can adjust all six categories globally with two decimal places. Bot kills do not award a human player's progress.

Choose a local combat indicator in DMF: small bar, bar + percentage, percentage only, or hidden. Hiding the indicator does not stop rewards or hide choice cards.

## Route and Buff choices

Compact animated cards have inset text, native Mortis border artwork and the native route names, Buff rank labels and complete effect descriptions, including formatted values. Long descriptions expand the cards instead of being cut off. The selected card flashes and lifts while the other options dim. After selection, automatic route awards and the last single candidate appear in the same card style with their full effects. Each round's automatic awards fade in together after selection, remain fully visible for three seconds, then fade out; the following choice then receives a full 60-second window. Press Ctrl+1, Ctrl+2 or Ctrl+3 to choose. Choices do not stop movement or capture the mouse; other menus and text entry take priority.

Each choice allows 60 seconds, after which the host chooses randomly. Further reward rounds queue behind the active choice. Each starts with its automatic route grant and a fresh 60-second choice window. Candidates follow native route and class eligibility. If fewer than three remain, only eligible entries are offered; an exhausted pool stops further choices.

Press Tab to view acquired Buffs in the native Mortis category. In progress and competition modes, the workspace Mortis editing tab is disabled. Rewards remain synchronized with the host and visible through the combat HUD and Tab display.

## Host settings and Realms

Without Realms, configure the mode, shared limit and kill weights through DMF. With Realms, the host has one global Mortis control row in the preparation list, including in an empty room. Per-player mode and point overrides are not provided. 

Click numeric settings to type or paste. Enter or clicking elsewhere confirms; Esc cancels. Realms plus/minus controls repeat after a 400 ms hold.

Guests follow host rules. Deployment indicators show readiness, missing/incompatible installations, resource loading, disabled state and lost connections. An unready or disconnected guest does not block the remaining players. Rejoining the same room and character during a mission retains acquired rewards; another character or mission has separate state. The host owns choices and rewards, and stale or duplicate replies cannot consume another reward. Host migration is not provided.

Reducing the limit restricts active Buffs while retaining saved choices; raising it can restore them. Changing reward mode during a mission starts a new reward run. Configure the intended mode before starting.

## Requirements and compatibility

Requires Darktide Mod Loader, Darktide Mod Framework and SoloPlay. Realms is optional for player-hosted co-op. English, Simplified Chinese and Traditional Chinese follow the game language.

Enable both the DMF switch and custom Mortis Buffs. The feature defaults off, with preselection and a 10-point shared limit. Disabling the mod removes its UI and applied effects while retaining saved choices.

Buffs use original game templates, identifiers and the mission-Buff manager. Native stacking and eligibility rules apply. When managing Mortis Trials, this mod handles rewards without the native modal picker. Other mods replacing the same reward flow can conflict. The mod does not alter permanent progression in official matchmaking.

## Compatibility

Compatible with Talent Point Manager and Realms Loadout. Both are optional; this mod keeps its own settings, Buff selections and rewards.

## Vortex installation

- Close the game and install the requirements. Import the ZIP with Install From File, enable it and select Deploy Mods.
- Place MortisBuffManager after SoloPlay in Load Order; enable Realms for co-op.
- Start the game and enable custom Mortis Buffs in Mod Options, then choose a mode and limit.

## Manual installation

- Close the game. Extract the ZIP into Darktide/mods, producing mods/MortisBuffManager.
- Add MortisBuffManager on its own line after SoloPlay in mods/mod_load_order.txt.
- Start the game and enable the feature in Mod Options.

## Credits

SoloPlay and Realms: deluxghost. Native Mortis systems, Buff definitions and referenced materials: Fatshark.

[Eligibility audit](diy/ELIGIBILITY-AUDIT.en.md)

local mod=get_mod("MortisBuffManager")
local path="MortisBuffManager/scripts/mods/MortisBuffManager/modules/diy/"
local function load(name) return mod:io_dofile(path..name) end
local Schema,Codec,Catalog,Engine=load("diy_schema"),load("diy_codec"),load("diy_catalog"),load("diy_engine")
local Library,Files,Game,Network=load("diy_library"),load("diy_files"),load("diy_game"),load("diy_network")
local Eligibility=load("diy_eligibility")
local WeaponTemplate=require("scripts/utilities/weapon/weapon_template")
local M={};mod.diy_mortis=M
local snapshot,owner,engine,api,network,elapsed,bindings,remote
local setup_cache=setmetatable({},{__mode="k"})
local function busy()
    local mode=mod.session_context().game_mode_name
    return mode and mode~="hub" and mode~="prologue_hub" and mode~="shooting_range" and mode~="prologue" or false
end
local function build(player)
    return Eligibility.capture(player,mod.mortis_diy_family and mod.mortis_diy_family(player),WeaponTemplate.weapon_template_from_item,not busy())
end
mod.mortis_build_setup=build
local function choose(snap,player,selected_ids)
    local setup=build(player)
    local options=snap.options
    if selected_ids then options=Schema.copy(options);options.mode="manual";options.selected=selected_ids end
    return Engine.choose(snap.document,options,options.seed,function(entry) return Eligibility.matches(entry,setup) end)
end
local library=Library.new(mod,"mortis",Catalog,Schema,Codec,Files,{name="MortisBuffManager",busy=busy,
    eligible=function(entry) return Eligibility.matches(entry,build(Network.local_player())) end})
mod.diy_library=library
local function authority()
    local c=mod.session_context()
    return mod:is_enabled() and (c.is_solo_play or c.is_realms_host) and c.is_server and mod._settings.enable_custom_mortis_buffs==true
end
local function finish()
    if engine then engine.finish() elseif api then api.finish() end
    snapshot=nil;owner=nil;engine=nil;elapsed=0;bindings=setmetatable({},{__mode="k"});remote={};M.local_choices=nil
    setup_cache=setmetatable({},{__mode="k"})
end
local function current()
    local token=Managers.state and Managers.state.game_session
    if not busy() or not token then if owner then finish() end;return end
    if token~=owner then finish();owner=token;snapshot=library.snapshot() end
    return snapshot
end
local function ensure()
    local snap=current()
    if not authority() then
        if engine then engine.finish();engine=nil;bindings=setmetatable({},{__mode="k"}) end
        return nil
    end
    if snap and authority() and snap.options.enabled and not engine then engine=Engine.new(snap.document,Catalog,api,snap.options.seed) end
    return authority() and engine or nil
end
local function request()
    local snap=current() or library.snapshot()
    local ids={}
    if snap.options.enabled then
        local p=Network.local_player()
        if busy() and p and build(p).complete then
            M.local_choices=M.local_choices or {};local key=tostring(p:character_id())
            if not M.local_choices[key] then M.local_choices[key]=choose(snap,p) end
            ids=choose(snap,p,M.local_choices[key])
        else ids=choose(snap,p) end
    end
    return {signature=snap.signature,ids=ids}
end
local function accept(p,value)
    local snap=current() or library.snapshot()
    if not snap.options.enabled then return false,"host_disabled" end
    if type(value)~="table" or value.signature~=snap.signature then return false,"config_mismatch" end
    if not build(p).complete then return false,"build_pending" end
    if type(value.ids)~="table" or #value.ids>32 then return false,"invalid_selection" end
    local available={};for _,e in ipairs(snap.document.entries) do if e.enabled then available[e.id]=true end end
    local seen={};local n=0
    for k,id in pairs(value.ids) do
        n=n+1
        if type(k)~="number" or k%1~=0 or k<1 or k>#value.ids or not available[id] or seen[id] then return false,"invalid_selection" end
        seen[id]=true
    end
    if n~=#value.ids or n>snap.options.max_total then return false,"invalid_selection" end
    local chosen=choose(snap,p,value.ids)
    if #chosen~=#value.ids then return false,"incompatible_selection" end
    local key=tostring(p:peer_id()):lower().."/"..tostring(p:character_id())
    remote=remote or {}
    if not remote[key] or not busy() then remote[key]=Schema.copy(value.ids) end
    return true,"ready"
end
network=Network.new(mod,Catalog,{context=Network.context,realms=Network.realms,local_player=Network.local_player,players=Network.players,
    request=request,accept=accept,snapshot=function(p,accepted)
        local e=ensure();return e and accepted and p.player_unit and e.effects(p.player_unit),accepted and "ready" or nil
    end})
api=Game.new(mod,Catalog,Engine,{name="MortisBuffManager",engine=ensure,authority=authority,skip_attack_report=true,
    family=mod.mortis_diy_family,
    available=function(entry,unit)
        local spawn=Managers.state and Managers.state.player_unit_spawn
        local p=spawn and spawn.owner and spawn:owner(unit)
        if not p then for _,candidate in pairs(Network.players()) do if candidate.player_unit==unit then p=candidate;break end end end
        if not p then return false end
        local setup=setup_cache[p];if not setup then setup=build(p);setup_cache[p]=setup end
        return Eligibility.matches(entry,setup)
    end,
    client_effects=network.effects,language=function() return mod:localize("diy_language") end})
function M.update(dt)
    setup_cache=setmetatable({},{__mode="k"})
    network.update(dt)
    local e=ensure();if not e then return end
    elapsed=(elapsed or 0)+dt;if elapsed<.1 then return end;local step=elapsed;elapsed=0
    local active={};local p=Network.local_player()
    for _,player in pairs(Network.players()) do
        local unit=player.player_unit
        if unit and api.alive(unit) then
            local ids={}
            if player==p then ids=request().ids
            elseif network.eligible(player) then ids=choose(snapshot,player,remote[tostring(player:peer_id()):lower().."/"..tostring(player:character_id())] or {}) end
            e.set_owner(unit,ids);active[unit]=true;bindings[unit]=true
        end
    end
    for unit in pairs(bindings) do if not active[unit] then e.set_owner(unit,{});bindings[unit]=nil end end
    api.update();e.tick(step)
end
function M.finish() network.finish();finish() end
M.enemy_died=api.enemy_died
function M.status() return {network=network.status,active=ensure()~=nil,signature=(current() or library.snapshot()).signature} end
mod.diy_api={version=1}
function mod.diy_api.paused(family) local e=ensure();return e and e.paused(family) or false end
function mod.diy_api.context(c)
    c=c or {};c.signal=c.signal or {};local e=ensure()
    if e then for name,t in pairs(e.signals) do if t>e.now then c.signal[name]=true end end end
    return c
end
mod.diy_api.status=M.status
finish()
return M

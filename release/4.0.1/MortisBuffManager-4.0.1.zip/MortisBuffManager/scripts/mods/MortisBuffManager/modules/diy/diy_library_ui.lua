-- Shared page model. Native views own widgets, focus, scaling and navigation.
local U={}
function U.build(ui,view,mod,library,Schema,Engine,examples,status)
    local function loc(key) return mod:localize("diy_"..key) end
    local function change(fn) return function() if not mod:is_enabled() then return end;fn();view._hcm_refresh=true;view._diy_revision=nil end end
    local doc,options=library.document,library.options
    local language=loc("language")
    local title=Schema.localize(doc.name,language)
    ui:text("diy_title",105,219,1370,42,title.."  ·  "..#doc.entries,28)
    ui:checkbox("diy_enabled",1515,218,280,48,loc(options.enabled and "disable" or "enable"),change(function()
        library.set_options({enabled=not options.enabled}) end),options.enabled)
    ui:button("diy_directory",105,282,250,48,loc("copy_dir"),change(library.copy_directory))
    ui:button("diy_scan",371,282,185,48,loc("scan"),change(library.scan))
    local file=library.files[library.selected_file]
    ui:button("diy_file",572,282,610,48,file and (library.selected_file.."/"..#library.files.."  "..file.."  ›") or loc("no_files"),#library.files>0 and change(function()
        library.selected_file=library.selected_file%#library.files+1 end))
    ui:button("diy_import",1198,282,185,48,loc("load"),file and change(function() library.import_file(file) end))
    ui:button("diy_paste",1399,282,185,48,loc("paste"),change(function()
        local raw=Clipboard and Clipboard.get and Clipboard.get()
        if type(raw)=="string" then library.import_text(raw,"clipboard") else library.last_error="diy_no_clipboard" end
    end))
    ui:button("diy_example",1600,282,195,48,loc("example"),change(function() library.export("starter-"..library.kind..".json",examples[library.kind]) end))
    ui:button("diy_mode",105,346,270,48,loc(options.mode=="random" and "random" or "manual"),change(function()
        library.set_options({mode=options.mode=="random" and "manual" or "random"}) end))
    ui:button("diy_seed",391,346,510,48,loc("seed")..options.seed,change(library.paste_seed))
    ui:button("diy_maximum",917,346,220,48,loc("total")..options.max_total,change(function() library.set_options({max_total=options.max_total%32+1}) end))
    for i=1,4 do
        ui:button("diy_tier_"..i,1153+(i-1)*164,346,150,48,loc("tier")..i..": "..options.tier_limits[i],change(function()
            local caps=Schema.copy(options.tier_limits);caps[i]=(caps[i]+1)%(i==4 and 2 or 17);library.set_options({tier_limits=caps}) end))
    end
    local picked={};for _,id in ipairs(options.selected) do picked[id]=true end
    local page=math.max(1,math.min(view._diy_page or 1,math.max(1,math.ceil(#doc.entries/8))));view._diy_page=page
    local start=(page-1)*8
    local shown
    for i=1,math.min(8,#doc.entries-start) do
        local entry=doc.entries[start+i]
        if view._diy_entry==entry.id then shown=entry end
        local eligible=library.eligible(entry)
        ui:checkbox("diy_entry_"..i,105,414+(i-1)*56,850,48,(eligible and "" or "×  ").."["..entry.tier.."] "..Schema.localize(entry.name,language),change(function()
            view._diy_entry=entry.id;library.toggle(entry.id)
        end),picked[entry.id],entry.id)
    end
    if not shown then for _,entry in ipairs(doc.entries) do if view._diy_entry==entry.id then shown=entry;break end end end
    shown=shown or doc.entries[start+1]
    if #doc.entries==0 then ui:text("diy_empty",125,435,790,220,loc("empty"),24,"muted") end
    ui:button("diy_prev",105,878,120,44,"‹",page>1 and change(function() view._diy_page=page-1 end))
    ui:text("diy_page",240,878,200,44,page.." / "..math.max(1,math.ceil(#doc.entries/8)),22)
    ui:button("diy_next",435,878,120,44,"›",start+8<#doc.entries and change(function() view._diy_page=page+1 end))
    ui:button("diy_clear",571,878,184,44,loc("clear"),change(function() library.set_options({selected={}}) end))
    ui:button("diy_export",771,878,184,44,loc("export"),change(function() library.export(doc.id.."-export.json") end))
    ui:text("diy_detail_title",1005,414,780,65,shown and Schema.localize(shown.name,language) or loc("details"),28,"gold")
    local lines={}
    if shown then
        lines[#lines+1]=shown.id.."  ·  "..loc("rules")..#shown.rules
        lines[#lines+1]=Schema.localize(shown.description,language)
        local allowed,reason=library.eligible(shown)
        if not allowed then lines[#lines+1]=mod:localize(reason or "diy_incompatible") end
        if shown.passive then
            local keys={};for key in pairs(shown.passive.stats or {}) do keys[#keys+1]=key end;table.sort(keys)
            for i,key in ipairs(keys) do if i<=10 then lines[#lines+1]=key.." = "..shown.passive.stats[key] end end
            if #keys>10 then lines[#lines+1]="… +"..(#keys-10) end
        end
    end
    ui:text("diy_detail",1005,488,780,288,table.concat(lines,"\n"),19,"muted")
    local selected=Engine.choose(doc,options,options.seed,library.eligible)
    ui:text("diy_preview",1005,784,780,70,loc("preview")..#selected.." / "..options.max_total.."  ·  "..library.signature(),20)
    local message=library.last_error
    if not message and options.enabled then
        local chosen={};for _,id in ipairs(selected) do chosen[id]=true end
        for _,entry in ipairs(doc.entries) do if chosen[entry.id] then
            for _,rule in ipairs(entry.rules) do for _,action in ipairs(rule.actions) do
                if action.type=="spawn_enemy" or action.type=="spawn_formation" then
                    local hed=get_mod("HavocEnemyDirector")
                    if not hed or not hed.diy_api or hed.diy_api.version~=1 then message="diy_need_hed" end
                elseif action.type=="pause_spawns" and action.name~="hed" and library.kind=="mortis" then
                    local hcm=get_mod("HavocConditionManager")
                    if not hcm or not hcm.diy_api then message="diy_need_hcm" end
                end
            end end
        end end
    end
    if message and message:match("^diy_") then message=mod:localize(message) end
    local network=status and status().network
    ui:text("diy_status",1005,854,780,68,message or (loc("ready")..(network and "\n"..loc("network_"..network) or "")),19,message and "danger" or "muted")
    ui:text("diy_help",105,934,1690,42,loc("help"),18,"muted")
end
return U

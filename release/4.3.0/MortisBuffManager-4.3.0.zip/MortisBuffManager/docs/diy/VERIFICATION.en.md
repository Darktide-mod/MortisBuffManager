# DIY verification and acceptance scope

Release candidates: MortisBuffManager 4.3.0, HavocConditionManager 4.2.0, HavocEnemyDirector 3.1.0. Native source: game Lua 1.12.5, commit 0f0cb45991e9305ef4a7b925370792d7d6035f95. These are offline checks, not a recorded game session.

| Area | Verification performed |
| --- | --- |
| JSON and schema | Malformed input, UTF-8, unknown fields, size/depth limits, stat kinds, event fields and all 46 starter entries. Invalid imports preserve prior valid data. |
| Runtime | Selection quotas/exclusivity, owner isolation, selector scope, temporary stacking/expiry, cooldown, delayed-action cancellation, removal/reselection, bounded queues and signals. |
| Native boundary | Original native buff reset/stat/proc methods, original health/toughness methods and complete ammo/stamina/warp-charge/overheat utility files. Engine unit services, attack execution, pickup creation and buff index allocation use fixtures. |
| Native inheritance | The actual class utility and DMF hooks execute against preloaded concrete player/minion classes. Both DIY mods apply once; minion proc overrides do not double-dispatch. Native idle request gating, activation scan, new enemy initialization, last-native-buff removal and final-owner restoration are exercised. |
| Lifecycle | Actual Mortis/HCM modules freeze mission snapshots, check library signatures and character choices, handle death/respawn, ownership loss, disable, exit, new missions and client authority. Native world services are fixtures. |
| Realms protocol | Host identity, membership, session nonce, character, monotone sequence, invalid/stale messages, three-second lease expiry, rate limits, shutdown and sequence retention across reload. Transport is simulated. |
| Files | Actual Windows Unicode paths and FFI file operations in isolated temporary application-data folders, atomic replacement, overwrite/path rejection and removal. |
| UI | Actual widget callbacks, import errors, mission locks, selection caps, pagination and stale callbacks; native private view structure; English, Simplified Chinese and Traditional Chinese layout bounds. Rendered previews are not gameplay screenshots. |
| HED | External request bounds, pending/admission pauses, expiry, shutdown, active-affix/signal predicates and existing native creation adapters; all existing director regression checks. |
| Existing behavior | The three projects' existing regression suites and source syntax/import checks. |

Live acceptance remains required for four-player prediction and latency, special keyword resources, interactions with other installed mods, actual rendering/input at the user's resolution and dense-encounter frame time. The existence of an identifier in the native catalog does not mean every weapon, class or damage path consumes it.

The source workspace includes six new DIY suites in development/diy-framework and each project's existing tests/run.py. Release validation additionally checks archive contents against source bytes, one-mod folder structure, the four required release files and the Vortex installer contract. It does not install or upload the mods.

Additional eligibility checks cover 128 native selector combinations, 132 actual ability combinations, 1000 seeds, host rejection, pending builds, stale cards and basic-box adapter ownership. See the [eligibility audit](ELIGIBILITY-AUDIT.en.md).

Additional offline checks execute native staff scheduling, spawning, cost and interruption, native explosion start and flame stack limits; generic ranged hooks and shotgun primitives use simulated damage boundaries. The actual mixed pool is sampled 25,000 times, and the shared selector 30,000 times. Tests cover native-first / DIY-only openings, all four switches, dynamic total/exclusive limits, room manifests, named missing definitions, atomic batches, direct search/numeric input and paginated three-language UI layouts. These do not establish live rendering, multiplayer prediction or dense-scene performance.

## Startup regression (4.1.1 / 4.0.3)

The native BuffExtensionBase file header is executed with network types unavailable to reproduce the original failure and poisoned require cache. A fresh loader then uses the actual Mod Loader require wrapper and DMF hook/require modules. Five load orders verify that both DIY runtimes register without requiring gameplay files, that past and future concrete classes receive hooks once, and that native stat overlays, minion update ownership, proc events and action boundaries still pass. The real mod entrypoints also run 1,000 updates after a failed DIY initialization, followed by mission exit and disable/unload as applicable. Native services and objects remain fixtures; no live game startup or mission is claimed.

## Mortis 4.1.2 runtime overhead

All three modes share the optimization. In the controlled 3,600-frame fixture, recurring session-table allocations fell from 16,306 (preselection) or 30,228 (progress/competition) to zero after warm-up; obsolete native exclusion checks fell from 3,600 to zero. In 1,000 live-build captures, profile ability lookups fell from 62,000 to zero, talent sorting from 2,000 to zero, and static weapon action scans from 2,000 to two. For 1,000 ordinary deaths reported twice, breed reads fell from 2,000 to 1,000, per-breed classifications from 2,000 to one, and boss-extension reads from 2,000 to zero; progress stayed exactly +10 at 0.01% per death. Zero-weight kills no longer invalidate the HUD snapshot. DIY notice checks remain bounded in every mode, with immediate checks when rules are replaced. Native services, rendering and damage effects are fixtures: these are operation counts, not FPS improvements. High counts of native Buffs can still execute their own proc, area-damage and visual work; that cost has not been measured in a live session.

## Mortis 4.1.3 workspace containment

The actual native UIViewHandler update/draw functions reproduce the old Realms overlap using the previous production shell, then verify the corrected workspace and the same older shell hosting the updated Mortis page. Realms main, grid and tooltip worlds are disabled below the workspace; the catalog and native navigation still receive input and draw above an opaque full-screen background. Checks cover three tab-switch/reopen cycles, child loading, Back, invalid-session closure, unchanged room state and restoration of all three worlds and input. The compatibility change belongs to one live parent instance and does not alter the optional provider class. Native widget checks confirm an opaque background remains visible across all three languages and catalog states. Engine resource allocation and raster drawing are recorded test boundaries; this is not a live-game screenshot or multiplayer acceptance test.

## Folder packages and executable Lua

Real Windows IO uses isolated temporary APPDATA, including Unicode paths, complete-folder writes, overwrite refusal, migration, startup discovery, runtime refresh and full exports. LuaJIT tests execute modules and callbacks using loader backups with ordinary loadstring/setfenv removed, and native strict-global behavior. Tests cover SHA-256 vectors through one MiB; scoped IDs/groups/signals; file, syntax, version, capability, dependency and aggregate-size errors; per-owner effects, queued actions, subscriptions, death/removal/error/finish cleanup; one-shot late-mod dependency resolution; distributed executable examples through both actual manager factories; mode-less Realms preparation; current mission fingerprints/resources staying frozen and next-mission refresh. Existing three-mode reward, host-policy, native startup, UI and performance suites remain part of release checks. Game managers/resources are simulated at the recorded native boundary; no live gameplay, rendered game screenshot or four-player result is claimed.

Reward/package separation checks cover native Realms +/- and typed DIY limits, 0/32 bounds, paste and cancellation, hold repeat, room/revision changes, fixed-progress independence, host APIs and actual HCM native numeric controls. Sixty three-language layouts pass text-bound checks. Saved tier caps no longer change weighted outcomes; source pool, eligibility, weights, total limits and exclusive groups remain covered. These are offline checks.

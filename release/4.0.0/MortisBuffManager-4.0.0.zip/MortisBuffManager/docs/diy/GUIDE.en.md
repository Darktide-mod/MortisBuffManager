# DIY talents and conditions

For MortisBuffManager 4.0.0, HavocConditionManager 4.0.0 and HavocEnemyDirector 3.1.0. The data contract is `Darktide.DIY` version `1`. Native API review uses game Lua 1.12.5, commit `0f0cb45991e9305ef4a7b925370792d7d6035f95`. Source, offline lifecycle and original native-method checks have passed. In-game multiplayer acceptance testing remains outstanding.

## Getting started

1. In the hub, enter `/mortisbuffs` and open **DIY talents** in the character workspace, alongside loadouts and talents. In HCM, open its existing settings page and select **DIY conditions**.
2. Choose **Export starter**. Mortis contains 11 examples; HCM contains 34 conditions and interface examples. The same files are included here as `starter-mortis.json` and `starter-conditions.json`.
3. Copy the folder path, open it in File Explorer, and edit the JSON. Refresh files, select a file and load it. Alternatively, copy a complete document and choose **Paste JSON**.
4. Select entries and enable DIY. Manual selection defaults to a total limit of six. Weighted selection also uses tier quotas; tier four is limited to one. Click the seed to paste an integer from 1 through 2147483646.
5. Start a new mission. The document and choices are frozen for that mission. Return to the hub to edit them. Start with one modest numerical effect before combining examples.

Folders:

```text
%APPDATA%/Fatshark/Darktide/MortisBuffManager/diy/
%APPDATA%/Fatshark/Darktide/HavocConditionManager/diy/
```

Loading replaces one complete library; files are not automatically merged. Unselected entries remain inactive. Export never overwrites an existing file. Invalid imports preserve the previous valid document and show the failing field path. Imports are data only: no Lua, executable expressions, external libraries or arbitrary code.

Mortis DIY is a separate starting talent layer available alongside all three native reward modes. It consumes neither native preselection points nor reward rounds and is not inserted into the native three-card reward pool. Enable both the Mortis master switch and DIY. It does not rewrite the official talent tree, items, inventory or backend rewards. HCM DIY entries remain separate from official circumstances.

## Document contract

```json
{
  "format": "Darktide.DIY", "version": 1, "kind": "mortis",
  "id": "my_talents", "name": "My talents",
  "entries": [{
    "id": "steady", "name": "Steady aim",
    "description": "Reload speed increases by 10%.",
    "tier": 1, "passive": {"stats": {"reload_speed": 0.1}}
  }]
}
```

Use `kind: "conditions"` for HCM. The two kinds cannot be imported into one another.

| Scope | Fields |
| --- | --- |
| Document | Required format, version, kind, id, name, entries; optional description |
| Entry | Required id, name, description; optional enabled (true), tier (1–4; default 1), weight (0.001–1000; default 1), exclusive_group, source_row |
| Applicability | targets, availability, conditions, match |
| Effects | passive, spawn, rules; at least one effective section is required |
| Passive | stats, keywords and/or modifiers |
| Spawn | HCM-only `health_multiplier` from 0.05 to 100; static targets only, incompatible with entry-level dynamic conditions |
| Rule | id, event, scope, interval, chance, cooldown, max_triggers, delay, conditions, match, actions |

IDs contain 1–64 bytes, start with a lowercase letter, and continue with lowercase letters, digits, `_` or `-`. Entry IDs must be unique within a library, and rule IDs within an entry. Name/description can be a string or a localization object with en, zh-cn and zh-tw keys; provide at least English or Simplified Chinese. Use `\n` for line breaks and ordinary `%` characters. Names are limited to 256 bytes, descriptions to 4096 bytes; the page displays a shorter details area while the file retains the full text.

The total limit, enabled flags and exclusive groups apply to both selection modes. Weighted selection additionally respects tier quotas; unused capacity does not fabricate entries. Identical canonical content, options and seed produce identical initial choices. Mortis availability is evaluated on the actual owner, so a randomly selected talent unavailable to that class is not automatically replaced.

### Selectors and conditions

`targets` defaults to `{"kind":"players"}`. Kinds are players/minions/all; Mortis entries must target players. Breeds and archetypes are lists of alternatives, tags must all match, exclude_tags reject any match, and different selector fields combine with AND. Identifiers must exist in `native-catalog.json`. Elites use `{"kind":"minions","tags":["elite"]}`.

Mortis-only `availability` can contain archetypes, families and talents arrays. All dimensions must match. Talents check the owner's profile values for true or a positive number; this does not grant those native talents. The native class and Mortis family IDs are included in the catalog.

A condition is `{"subject":"self","field":"health","op":"lt","value":0.5}`. Subject defaults to self, or may be target/attacker. Match defaults to all, or may be any. Missing data fails every comparison, including ne and not_contains.

| Fields | Meaning |
| --- | --- |
| health, toughness, corruption, ammo, stamina, warp_charge, overheat | Fractions from 0 to 1. Ammo reads the secondary weapon's clips plus reserve over total capacity |
| coherency | Native coherency count; examples require at least two, following the game's own count semantics |
| progress | Main-path progress in metres, not percent |
| load, players, monsters | Native challenge load, capable player count, aggroed monsters |
| elapsed | Seconds elapsed in the current DIY runtime instance |
| stage, phase | Native pacing state string; HED phase is build/pressure/recovery |
| breed, archetype, attack_type | Native identifiers; attack type must be supplied by the event |
| critical, weakspot | Boolean values supplied by the current event |
| sprinting, dodging, sliding, knocked_down | Current character state |
| in_combat | This runtime observed damage dealt/taken or a hit within eight seconds; not a new authoritative native combat state |
| native_condition, affix, signal, tag | Sets of official circumstance IDs, active HCM DIY entry IDs, unexpired signals and unit tags |
| event.FIELD | Whitelisted scalar event payload; 95 names/types are listed in the catalog. No individual event necessarily supplies all fields |

Numbers support eq/ne/gt/ge/lt/le; strings and booleans eq/ne; sets contains/not_contains. There are no arbitrary formulas, cross-unit numeric expressions or script execution.

### Native attributes and keywords

The catalog exposes 411 stat identifiers, 181 keywords and 105 native events. This is an expression surface, not a claim that every identifier affects every weapon, class, enemy or damage path. The relevant native consumer must read it. Specialized keywords may require additional native state or resources.

| Native type | Interpretation |
| --- | --- |
| additive_multiplier | Add a delta to the native multiplier. Example: reload_speed 0.1 adds 10%; recoil_modifier -0.5 subtracts 50 percentage points from that multiplier |
| multiplicative_multiplier | Multiply the native value and other layers. damage_taken_multiplier 0.8 multiplies incoming damage by 0.8 |
| value | Add a native numerical value. Its unit depends on the consumer; probability values commonly use 0.1 for ten percentage points |
| max_value | Take the maximum of native and DIY contributions; stack count does not repeatedly add it |

Each effect accepts at most 64 stats and 32 keywords. Individual values are bounded by -1000 and 1000; multiplicative/max values cannot be negative, and additive multiplier deltas cannot be below -1. Aggregate values are also bounded. Extreme values can exceed a native subsystem's practical assumptions.

Keywords are enabled by an array of identifiers. DIY cannot turn off a keyword owned by another native buff/mod. Removal withdraws only DIY's contribution. Modifiers include ammo_pickup_multiplier (0–10, multiplied across layers) and ammo_pickup_failure_chance (0–1, combined as one minus the product of success probabilities). Pickup scaling modifies the result of the native ammo pickup calculation; it does not disable medical or deployed crates.

### Rules and events

Rules default to chance 1, cooldown 0, max_triggers 0 (unlimited) and delay 0. The runtime still enforces a minimum 0.05-second interval per rule state. Cooldown allows 0–600 seconds, delay 0–120 seconds and max_triggers 0–10000. Conditions have independent all/any matching at entry and rule level. Scope defaults to unit; HCM can use global to share cooldown/count across event sources. Global scope still respects the entry selector. Mortis rules always belong to the selecting owner.

Five additional events supplement the native list:

- interval requires an interval of 0.1–600 seconds. A delayed update does not replay all missed periods.
- spawn observes player creation, and enemy creation in HCM.
- mission_start fires when the runtime first observes a player unit. A newly created respawn unit can produce it again; unit-scope max_triggers=1 is not a character-wide once-per-mission guarantee.
- enemy_died broadcasts a death. HCM self is the victim; Mortis self is each living talent owner. Use native on_kill for rewards belonging only to the killer. Target is the victim, and attacker is the source when available.
- signal is dispatched on the next update; filter event.signal_name. HCM global signal rules can run without a unit, so use target=players for team actions. Cross-mod integration shares signal state; it does not dispatch another mod's signal event.

Native proc parameters depend on the original event. Source_row is documentation metadata only.

### Complete action surface

Common target values are self (default), target, attacker, players, nearby_players, minions, nearby_minions and matching. Nearby targets are centred on self; radius defaults to eight metres and accepts 1–50. Matching uses the entry selector. Non-effect fanout is bounded to four players or 64 minions. Dead units do not receive resource, damage or native-status actions.

| Type | Fields and behavior |
| --- | --- |
| effect | Required effects and duration (0.1–600s), optional max_stacks (1–500; default 1) and refresh (true). Stacks share one expiry; false prevents refresh |
| heal | Nonnegative amount; native buff healing, respecting corruption, healing multipliers and prevention keywords |
| corruption | Nonnegative amount removes corruption through buff_corruption_healing across wound boundaries; does not separately restore ordinary health or inflict corruption |
| toughness | Positive recovery respects native modifiers; negative values apply native toughness damage and regeneration delay |
| ammo | Positive reserve addition; negative reserve-first, then clip removal across equipped weapon slots; rounded toward zero |
| grenades | Adjust native grenade ability charges within its actual capacity |
| ability_cooldown | Nonnegative seconds reduce combat ability cooldown; fraction uses its maximum cooldown |
| stamina | Add or consume native stamina, preserving cost modifiers and depletion events |
| warp_charge | Flat values are percentage points, fraction is 0–1. Positive values add peril without directly triggering explosion; negative values quell. Requires a native peril archetype |
| overheat | Flat values are percentage points, fraction is 0–1. Positive values follow native heat modifiers/lockout/explosion; negative values vent. Requires a secondary weapon with heat configuration |
| damage | Nonnegative direct health damage through a private native profile and the original attack path. Bypasses toughness, not necessarily every native reduction or immunity |
| kill | Explicit target or minion selector required, no amount. Restricted to ordinary freely spawnable catalog minions; cannot execute players or protected mission entities |
| native_buff | Name from 15 audited statuses; duration defaults to 10s, maximum 120s; count 1–10. Native expiry can occur earlier than DIY's removal deadline |
| signal | ID name and duration 0.1–600s publish a temporary state flag |
| pause_spawns | Name all/hordes/trickle_hordes/roamers/specials/monsters/hed and duration 0.1–600s. Holds permission checks and HED scheduling; does not remove existing enemies or promise to pause scripts bypassing Pacing |
| spawn_formation | Name is an existing HED formation ID in the frozen mission configuration; one scheduled request |
| spawn_enemy | Breed from 40 supported minions; count 1–16 for ordinary/special enemies, one monster per JSON action; uses HED placement/capacity/native slots |
| pickup | Native pickup name; count 1–4; drops beside the target rather than forcing it into inventory |
| sound | One of 456 native UI sound identifiers, played locally on the host; no external music loading |
| notification | Text string or localization object, maximum 512 bytes; local host notification |

Resource amount_kind defaults to flat. Fraction uses maximum capacity, not current holdings. Ammo alone supports current_fraction, for removing a fraction of remaining ammunition. Heal/toughness/damage support event_damage, multiplying event damage/damage_amount/damage_dealt by amount (0–5); missing damage means zero.

Signal, pause and spawn requests ignore target/radius; sound and notification execute once. Effect actions targeting players/minions/matching create a dynamic selector layer, so newly matching units can receive it during its lifetime. Nearby effects bind a finite set at activation. A temporary unit layer does not end early merely because the original trigger condition becomes false.

## HED integration

Spawn actions require HED with its director enabled. An unavailable director rejects requests instead of bypassing native placement. Native spawn pauses require enabled HCM. Mortis publishes its own signals and pause flags; HED reads its hed/all flags, and HCM merges Mortis signals/pauses with its own. Cross-mod flags are shared state, not executable requests from clients.

HCM exposes diy_api.version=1, active(), paused(family), context(table), emit_signal(name,duration) and status(). Active returns selected HCM IDs; context writes affix and signal sets. Mortis exposes paused(), context() and status(), sharing signals without presenting private talents as global affixes.

HED exposes status() and request(request):

```lua
local hed = get_mod("HavocEnemyDirector")
local ok, id_or_reason = hed.diy_api.request({
    breed = "chaos_poxwalker", count = 2,
    source = "my_mod/my_entry/my_rule", seed = 12345,
})
```

Only formation or breed (exclusive), count, source and seed are accepted. Formation count must be omitted or one. External breed requests allow at most 16 units or three monsters; JSON monster actions use one. Source permits letters, digits and `_:/-`, up to 192 bytes. Seed is an optional integer 1–2147483646; omission uses the director seed. True means admitted to the queue, not guaranteed creation. Failures include director_not_ready, request_target, request_breed, formation_missing, request_capacity and mission_request_budget.

HED rule editors support affix_active and signal_active; click the value to paste an ID. The starter signal uses diy_pressure. HCM enemy spawn events expose event.spawn_source: ordinary HED units use hed_director and ordinary DIY reinforcements hed_diy; other native sources retain their batch label or native. Monsters/specialists use separate native registration and slot paths, so those two labels are not guaranteed for them.

There are at most 128 accepted external requests per mission and 32 retained external states. A request can wait at most 120 seconds. Existing placement, visibility, route, per-breed capacity, live-group and paced submission limits still apply. Requests are not corpse-location cloning, strict FIFO, or guaranteed delivery.

## Multiplayer and lifecycle

Actions execute only with local SoloPlay/Realms host authority. Participating Realms clients need the corresponding current mod. Mortis also requires the same canonical library as the host; the host approves IDs and freezes each character's choice for the mission. HCM is selected by the host, so clients need not load an identical conditions file.

Clients receive aggregate effects only for their own player, not executable programs. Packets validate host identity, membership, character, session nonce and increasing sequence. Effects expire after three seconds without a fresh state. Host snapshots run roughly every 0.5 seconds and the effect runtime roughly every 0.1 seconds; clients can observe that scale of delay. Prediction behavior, specialized keyword resources and complete four-player combat still require live testing.

Limits: 512 KiB/file, 30000 JSON nodes, depth 20, 128 entries, 16 rules/entry, eight actions/rule and 12 conditions/list. Each tick evaluates at most 128 triggers and executes 64 actions, with 512 queued actions, 128 layers per unit/global selector store, 256 tracked native statuses and 32 pickups per library/mission. Saturation can reject or defer work; this is not lossless capture of unlimited event traffic.

Exit, authority loss, disable and ownership withdrawal clean up owned temporary states and queues. Completed damage, healing, ammunition changes, pickups and spawned enemies are not rolled back. Native buff removal targets only indices allocated by this runtime.

Native player and minion classes are hooked separately because the game's class utility copies inherited methods. Selected enemy effects and rules keep otherwise-idle minion buff updates active, including enemies already present when the runtime starts. Both DIY mods share this update ownership. When the final owner stops, empty-buff enemies have their native stats reset and return to native idle behavior; enemies with native buffs retain native updates. Player-only passive libraries do not activate idle enemy updates. Broad enemy effects still add per-enemy work and should be profiled in a live dense encounter.

See IMAGE-ASSESSMENT.en.md for every supplied image row, including blank and underspecified entries, and NATIVE-CATALOG.en.md/native-catalog.json for identifiers. Fatal-hit interception, player bleeding, aggro resets, enemy transformation, projectiles/explosions, loot pools, HUD hiding, external media, inventory changes, mission interactions and vehicles require dedicated adapters. Extend the validated schema and native boundary together, with original-method tests and examples; change the schema version when changing semantics.

local mod = get_mod("MortisBuffManager")
if mod._workspace_shell_class then return mod._workspace_shell_class end
local BaseView = require("scripts/ui/views/base_view")
local UIWidget = require("scripts/managers/ui/ui_widget")
local Buttons = require("scripts/ui/pass_templates/button_pass_templates")
local Router = mod:io_dofile("MortisBuffManager/scripts/mods/MortisBuffManager/modules/workspace_router")
local Shell = class("MortisBuffManagerWorkspaceShell", "BaseView")
mod._workspace_shell_class = Shell
local function definition()
  local scene = { screen = { size = { 1920, 1080 }, scale = "fit" },
    header = { scale = "fit_width", vertical_alignment = "top", size = { 0, 100 }, position = { 0, 0, 900 } },
    navigation = { parent = "header", horizontal_alignment = "center", vertical_alignment = "top",
      size = { 220, 52 }, position = { -96, 24, 2 } },
    close = { parent = "header", horizontal_alignment = "right", vertical_alignment = "top",
      size = { 150, 52 }, position = { -24, 24, 2 } },
    empty = { parent = "screen", horizontal_alignment = "center", vertical_alignment = "center",
      size = { 1100, 180 }, position = { 0, 0, 0 } } }
  return { scenegraph_definition = scene, widget_definitions = {
    header = UIWidget.create_definition({ { pass_type = "rect", style = { color = { 255, 12, 18, 20 } } } }, "header"),
    close = UIWidget.create_definition(Buttons.terminal_button, "close",
      { text = mod:localize("workspace_close"), original_text = mod:localize("workspace_close") }),
    empty = UIWidget.create_definition({ { pass_type = "rect", style = { color = { 240, 12, 18, 20 } } },
      { pass_type = "text", value_id = "text", style = { font_type = "proxima_nova_bold", font_size = 24,
        text_color = { 255, 215, 215, 215 }, text_horizontal_alignment = "center", text_vertical_alignment = "center",
        offset = { 24, 0, 1 }, size = { 1052, 180 } } } }, "empty", { text = mod:localize("workspace_unavailable") }),
  } }
end

function Shell:init(settings, context)
  self._workspace_session_owned, self._workspace_invalid = true, false
  self._context, self._preview_player = context, context.player
  self._is_readonly = false
  self._character = context.player:character_id()
  self._connection = Managers.connection and (Managers.connection._connection_host or Managers.connection._connection_client)
  self._navigation, self._entries, self._page_events = {}, {}, {}
  Shell.super.init(self, definition(), settings, context)
  self._pass_draw = true
end

function Shell:_refresh_navigation()
  local entries = Router.entries(self._preview_player)
  local changed = #entries ~= #self._entries
  for i, entry in ipairs(entries) do if entry ~= self._entries[i] then changed = true end end
  if not changed then return end
  -- Remove widgets from both rendering and input collections. Missing pages
  -- have no dormant widget, callback, localized label or reserved tab slot.
  for _, widget in ipairs(self._navigation) do
    self:_unregister_widget_name(widget.name)
    for i = #self._widgets, 1, -1 do
      if self._widgets[i] == widget then table.remove(self._widgets, i); break end
    end
  end
  self._navigation, self._entries = {}, entries
  for i, entry in ipairs(entries) do
    local label = entry.label()
    local widget = self:_create_widget("navigation_" .. entry.id,
      UIWidget.create_definition(Buttons.terminal_button, "navigation",
        { text = label, original_text = label }, nil, { text = { font_size = 24 } }))
    widget.offset[1] = (i - (#entries + 1) / 2) * 236
    widget.content.hotspot.pressed_callback = function() self:select_page(entry.id) end
    self._widgets[#self._widgets + 1] = widget
    self._navigation[i] = widget
  end
end

function Shell:on_enter()
  Shell.super.on_enter(self)
  self:_refresh_navigation()
  self._widgets_by_name.close.content.hotspot.pressed_callback = function()
    if self:can_exit() then Managers.ui:close_view(mod._workspace_window_name) end
  end
  local initial = mod._workspace_requested_tab or self._context.initial_page
  mod._workspace_requested_tab = nil
  if not self:select_page(initial) then
    for _, entry in ipairs(self._entries) do if self:select_page(entry.id) then break end end
  end
end

function Shell:event_workspace_nodes_updated(...)
  if self._page and self._page.nodes_updated then self._page.nodes_updated(self, ...) end
end

function Shell:select_page(tab)
  local page = Router.page(tab, self._preview_player)
  if not page or (page.available and not page.available(self._preview_player)) then return false end
  if self._selected_page == tab and self._child and self._page == page then self._requested_page = nil; return true end
  if self._child then
    local current = Managers.ui:view_instance(self._child)
    if current and current.can_exit and not current:can_exit() then return false end
    if current and self._child == page.view_name and page.can_select and not page.can_select(current, tab) then return false end
  end
  self._requested_page = tab
  return true
end

function Shell:_close_page()
  if not self._child then return end
  local page, child = self._page, Managers.ui:view_instance(self._child)
  if not self._workspace_invalid and page and page.commit then page.commit(self) end
  if page and page.nodes_event and self._page_events[page.nodes_event] then
    self:_unregister_event(page.nodes_event)
    self._page_events[page.nodes_event] = nil
  end
  self._closing_views = child and child.workspace_children and child:workspace_children() or {}
  self._closing_views[#self._closing_views + 1] = self._child
  Managers.ui:close_view(self._child, true)
  self._child, self._page = nil, nil
end

function Shell:_finished_closing()
  for _, name in ipairs(self._closing_views or {}) do if Managers.ui:view_active(name) then return false end end
  self._closing_views = nil
  return true
end

function Shell:update(dt, t, input_service)
  local connection = Managers.connection and (Managers.connection._connection_host or Managers.connection._connection_client)
  local player = Managers.player and Managers.player:local_player_safe(1)
  local profile = player and not player.__deleted and player:profile()
  if not profile or not profile.archetype or not mod:is_enabled() or not self._preview_player or self._preview_player.__deleted
    or player ~= self._preview_player or player:character_id() ~= self._character or connection ~= self._connection then
    self._workspace_invalid = not profile or not profile.archetype or player ~= self._preview_player or not player or player.__deleted
      or player:character_id() ~= self._character or connection ~= self._connection
    Managers.ui:close_view(mod._workspace_window_name, true); return false, true
  end
  self:_refresh_navigation()
  local current_page = Router.page(self._selected_page, player)
  if self._child and self._page ~= current_page then
    local tab = self._selected_page
    self:_close_page()
    self._selected_page = nil
    self._requested_page = current_page and tab or "equipment"
  end
  for i, entry in ipairs(self._entries) do
    local page, hotspot = entry.page, self._navigation[i].content.hotspot
    hotspot.disabled = page.available and not page.available(player) or false
    local current = self._child == page.view_name and Managers.ui:view_instance(self._child)
    if current and page.can_select and not page.can_select(current, entry.id) then hotspot.disabled = true end
    hotspot.is_selected = entry.id == self._selected_page
  end
  if self._requested_page then
    local requested = Router.page(self._requested_page, player)
    if requested and self._child == requested.view_name and requested.select then
      local current = Managers.ui:view_instance(self._child)
      if current and requested.select(current, self._requested_page) then
        self._selected_page, self._requested_page = self._requested_page, nil
      end
    else
      if self._child then self:_close_page() end
      if self:_finished_closing() then
        local tab, page = self._requested_page, requested
        self._requested_page = nil
        if page and (not page.available or page.available(player)) then
          self._selected_page, self._page, self._child = tab, page, page.view_name
          if page.nodes_event and not self._page_events[page.nodes_event] then
            self:_register_event(page.nodes_event, "event_workspace_nodes_updated")
            self._page_events[page.nodes_event] = true
          end
          if page.prepare then page.prepare(self) end
          Managers.ui:open_view(page.view_name, nil, nil, nil, nil, { parent = self,
            player = player, player_mode = true, can_exit = true, is_readonly = false,
            workspace = true, workspace_tab = tab, current_profile_equipped_talents = self._current_profile_equipped_talents })
        end
      end
    end
  end
  self._widgets_by_name.empty.visible = not self._child and self:_finished_closing()
  if input_service:get("back") and self:can_exit() then Managers.ui:close_view(mod._workspace_window_name) end
  Shell.super.update(self, dt, t, input_service)
  return false, true
end

function Shell:can_exit()
  local child = self._child and Managers.ui:view_instance(self._child)
  return not child or not child.can_exit or child:can_exit()
end

function Shell:on_exit()
  self:_close_page()
  Shell.super.on_exit(self)
end

return Shell
